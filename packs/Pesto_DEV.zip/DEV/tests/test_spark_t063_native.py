import hashlib
import re
import unittest
from pathlib import Path

DEV = Path(__file__).resolve().parents[1]
SUITE = DEV / 'tests' / 'Run-CompiledHelpers63Tests.ps1'
LOADER = DEV / 'wad' / 'Pesto-Common.ps1'
MODULE = DEV / 'wad' / 'Pesto.Engine.Runtime.ps1'
DLL = DEV / 'wad' / 'Pesto.Runtime.dll'
WAD = DEV / 'wad'

NATIVE_SURFACE = {
    'Pesto.NativeShell|shell32.dll|SetCurrentProcessExplicitAppUserModelID',
    'Pesto.NativeShell|user32.dll|SendMessage',
    'Pesto.NativeShell|user32.dll|DestroyIcon',
    'Pesto.NativePipe17|kernel32.dll|GetNamedPipeClientProcessId',
}


def read(path):
    assert path.is_file(), 'Fichier source introuvable : ' + str(path)
    return path.read_text(encoding='utf-8-sig')


class TestCompiledHelpers63(unittest.TestCase):
    """Contrôles statiques ; l'exécution est jouée par tests/Run-CompiledHelpers63Tests.ps1."""

    def test_suite_epingle_la_surface_native(self):
        suite = read(SUITE)
        m = re.search(r"\$expectedNative=@\(([^)]*)\)", suite)
        self.assertIsNotNone(m, 'Liste native épinglée absente de la suite')
        pinned = set(re.findall(r"'([^']+)'", m.group(1)))
        self.assertEqual(pinned, NATIVE_SURFACE,
                         'La surface native épinglée a divergé de la liste qualifiée sur cible')

    def test_dll_livree_correspond_a_lempreinte_epinglee(self):
        digest = hashlib.sha256(DLL.read_bytes()).hexdigest()
        for path in (LOADER, MODULE):
            text = read(path)
            m = re.search(r"\$expected='([0-9a-f]{64})' # PESTO_COMPILED_SHA256", text)
            self.assertIsNotNone(m, 'Marqueur d\'empreinte absent de ' + str(path))
            self.assertEqual(m.group(1), digest,
                             'L\'empreinte épinglée ne correspond plus à la DLL livrée : ' + str(path))

    def test_aucun_add_type_compilant_dans_le_produit(self):
        # L'évaluation 63 est livrée : les sites Add-Type du produit ne chargent que des assemblys.
        offenders = []
        for ps1 in sorted(WAD.glob('*.ps1')):
            if ps1.name == 'Pesto.Engine.Runtime.ps1':
                continue
            for line in read(ps1).splitlines():
                stripped = line.strip()
                if re.match(r'^(Add-Type|\[void\]\s*Add-Type|\s*Add-Type)\b', stripped) or 'Add-Type ' in stripped:
                    if 'Add-Type' not in stripped or stripped.startswith('#'):
                        continue
                    if not re.search(r'Add-Type\s+-AssemblyName', stripped):
                        offenders.append(ps1.name + ': ' + stripped[:80])
        self.assertEqual(offenders, [],
                         'Des sites Add-Type compilant sont réapparus dans wad/ : ' + '; '.join(offenders))

    def test_porte_du_canal_garde_le_secret(self):
        for path in (DEV / 'wad' / 'Pesto-Operations.ps1', MODULE):
            text = read(path)
            gate = text.find('Test-PestoPipeClient -Pipe')
            secret = text.find('GetNetworkCredential().Password')
            self.assertGreater(gate, -1, 'Porte du canal absent de ' + str(path))
            self.assertGreater(secret, -1, 'Lecture du secret absente de ' + str(path))
            self.assertLess(gate, secret,
                            'La porte native ne précède plus la lecture du secret dans ' + str(path))


if __name__ == '__main__':
    unittest.main()

﻿#requires -Version 5.1
# Extensions facultatives et préparateurs. Rien ne s'exécute à l'import.
# Les mutations Pesto restent exclusivement dans son moteur vérifié.

function Test-PestoScenarioInput {
    [CmdletBinding()]
    param([Parameter(Mandatory=$true)]$Scenario,[Parameter(Mandatory=$true)]$Values)
    foreach($property in $Scenario.PSObject.Properties){if($property.Name -cnotin @('Schema','Name','Required','Allowed','Locked')){throw 'Champ de scénario inconnu.'}}
    if($Scenario.Schema -ne 1 -or [string]$Scenario.Name -notmatch '^.{1,80}$'){throw 'Scénario invalide.'}
    $fields=@('Type','SiteCode','ServiceCode','TargetOU')
    foreach($map in @($Scenario.Allowed,$Scenario.Locked)){
        if($null -eq $map){continue}
        foreach($property in $map.PSObject.Properties){if($property.Name -cnotin $fields){throw 'Champ de règle inconnu.'}}
    }
    $errors=[Collections.Generic.List[string]]::new()
    foreach($property in $Values.PSObject.Properties){if($property.Name -cnotin $fields){$errors.Add('Champ non admis : '+$property.Name)}}
    if(@($Scenario.Required).Count -gt 5){throw 'Trop de champs requis.'}
    foreach($field in @($Scenario.Required)){
        if($field -cnotin $fields){throw 'Champ requis inconnu.'}
        if([string]::IsNullOrWhiteSpace([string]$Values.$field)){$errors.Add('Champ obligatoire : '+$field)}
    }
    foreach($field in $fields){
        if($null -ne $Values.PSObject.Properties[$field] -and ($Values.$field -isnot [string] -or $Values.$field.Length -gt 4096 -or $Values.$field -match '[\x00-\x1f\x7f]')){$errors.Add('Valeur invalide : '+$field)}
        if($Scenario.Allowed -and $null -ne $Scenario.Allowed.PSObject.Properties[$field]){
            $allowed=@($Scenario.Allowed.$field)
            if($allowed.Count -gt 200 -or @($allowed|Where-Object{$_ -isnot [string]}).Count){throw 'Valeurs autorisées invalides.'}
            if($Values.$field -cnotin $allowed){$errors.Add('Valeur hors scénario : '+$field)}
        }
        if($Scenario.Locked -and $null -ne $Scenario.Locked.PSObject.Properties[$field] -and $Values.$field -cne $Scenario.Locked.$field){$errors.Add('Champ verrouillé : '+$field)}
    }
    [pscustomobject]@{Valid=($errors.Count -eq 0);Errors=$errors.ToArray();Scope='Formulaire uniquement ; droits AD et politique moteur restent obligatoires.'}
}

function New-PestoAttributeProposal {
    [CmdletBinding()]
    param([Parameter(Mandatory=$true)][Guid]$ObjectGuid,[Parameter(Mandatory=$true)]$Current,[Parameter(Mandatory=$true)]$Requested)
    if($ObjectGuid -eq [Guid]::Empty){throw 'Identité AD requise.'}
    $changes=@(foreach($property in $Requested.PSObject.Properties){
        if($property.Name -cnotin @('description','location','managedBy')){throw ('Attribut non autorisé : '+$property.Name)}
        if($property.Value -isnot [string] -or $property.Value.Length -gt 1024 -or $property.Value -match '[\x00-\x1f\x7f]'){throw 'Valeur d’’attribut invalide.'}
        if($property.Name -eq 'managedBy' -and $property.Value -and $property.Value -notmatch '^(CN|OU)=.+,DC='){throw 'managedBy attend un DN validé séparément.'}
        if([string]$Current.($property.Name) -cne $property.Value){[pscustomobject]@{Attribute=$property.Name;Before=[string]$Current.($property.Name);After=$property.Value}}
    })
    [pscustomobject]@{Schema=1;Purpose='PestoAttributeReview';ObjectGuid=$ObjectGuid.ToString('D');Utc=[DateTime]::UtcNow.ToString('o');Changes=$changes;Executable=$false}
}

function New-PestoAuditExport {
    [CmdletBinding()]
    param([Parameter(Mandatory=$true)]$Result)
    $id=[Guid]::Empty
    if(-not[Guid]::TryParse([string]$Result.OperationId,[ref]$id) -or $id -eq [Guid]::Empty){throw 'Identifiant opération requis.'}
    if($Result.ExitCode -isnot [int] -and $Result.ExitCode -isnot [long]){throw 'Code de résultat invalide.'}
    if([string]$Result.Mode -cnotin @('Join','UnattendedJoin','Rename','Move','RenameMove')){throw 'Mode ou état audit inconnu.'}
    $state=[string]$Result.State
    if($state -ceq 'Prepared'){throw 'Préparation sans identifiant d''opération : rien à auditer.'}
    if($state -cnotin @('NotStarted','Running','PendingRestart','RestartRequested','Verified','Uncertain','Failed','Refused','Partial','Protection','MoveReady')){throw 'Mode ou état audit inconnu.'}
    # Transport libre pour le collecteur de l’’organisation ; aucun envoi automatique.
    [pscustomobject][ordered]@{Schema=1;Product='Pesto';OperationId=$id.ToString('D');Mode=[string]$Result.Mode;State=[string]$Result.State;
        ExitCode=[int]$Result.ExitCode;RestartRequired=[bool]$Result.RestartRequired;ExportedUtc=[DateTime]::UtcNow.ToString('o')}
}

Export-ModuleMember -Function Test-PestoScenarioInput,New-PestoAttributeProposal,New-PestoAuditExport

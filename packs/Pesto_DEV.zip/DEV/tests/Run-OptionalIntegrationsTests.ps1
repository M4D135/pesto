﻿#requires -Version 5.1
[CmdletBinding()]
param([string]$ReportPath='')
$ErrorActionPreference='Stop';Set-StrictMode -Off
$dev=Split-Path $PSScriptRoot -Parent
Import-Module (Join-Path $dev 'integrations/Pesto.Optional.psm1') -Force
. (Join-Path $dev 'wad/Pesto-ManagedPolicy.ps1')
$cases=[Collections.Generic.List[object]]::new()
function Assert-Optional {param($Value);if(-not $Value){throw 'Condition fausse'}}
function Reject-Optional {param([scriptblock]$Body);$failed=$false;try{& $Body|Out-Null}catch{$failed=$true};Assert-Optional $failed}
function Case-Optional {param($Name,[scriptblock]$Body);try{& $Body;$cases.Add([pscustomobject]@{Name=$Name;Passed=$true;Error=''});Write-Host "PASS $Name"}catch{$cases.Add([pscustomobject]@{Name=$Name;Passed=$false;Error=$_.Exception.Message});Write-Host "FAIL $Name : $($_.Exception.Message)"}}
Case-Optional 'Scénario requis autorisé et verrouillé' {
    $s=[pscustomobject]@{Schema=1;Name='Paris';Required=@('Type','ServiceCode');Allowed=[pscustomobject]@{Type=@('P','S')};Locked=[pscustomobject]@{SiteCode='PA'}}
    Assert-Optional (Test-PestoScenarioInput $s ([pscustomobject]@{Type='P';ServiceCode='INF';SiteCode='PA'})).Valid
    $r=Test-PestoScenarioInput $s ([pscustomobject]@{Type='V';SiteCode='LY'});Assert-Optional (-not $r.Valid -and $r.Errors.Count -eq 3)
}
Case-Optional 'Attributs complémentaires : aperçu non exécutable fermé' {
    $p=New-PestoAttributeProposal -ObjectGuid '22222222-2222-4222-8222-222222222222' -Current ([pscustomobject]@{description='A'}) -Requested ([pscustomobject]@{description='B'})
    Assert-Optional (-not $p.Executable -and $p.Changes.Count -eq 1 -and $p.Changes[0].Before -ceq 'A')
    Reject-Optional {New-PestoAttributeProposal -ObjectGuid '22222222-2222-4222-8222-222222222222' -Current ([pscustomobject]@{}) -Requested ([pscustomobject]@{userAccountControl='8192'})}
}
Case-Optional 'Export audit fermé sans détails sensibles' {
    $r=[pscustomobject]@{OperationId='33333333-3333-4333-8333-333333333333';Mode='Rename';State='PendingRestart';ExitCode=3010;RestartRequired=$true;Password='FAUX';Message='secret=FAUX'}
    $a=New-PestoAuditExport $r
    Assert-Optional (($a|ConvertTo-Json) -notmatch 'FAUX|Password|Message')
}
Case-Optional 'GPO seulement restrictive et sans mutation du config objet' {
    $local=[pscustomobject]@{IncidentMode=$false;UnattendedJoinEnabled=$true;UnattendedOperationsEnabled=$true;MaxBatch=100}
    $managed=[pscustomobject]@{Values=[pscustomobject]@{IncidentMode=1;DisableUnattendedJoin=1;DisableUnattendedOperations=1;MaxBatch=50}}
    $r=Merge-PestoManagedPolicy $local $managed
    Assert-Optional ($r.IncidentMode -and -not $r.UnattendedJoinEnabled -and -not $r.UnattendedOperationsEnabled -and $r.MaxBatch -eq 50)
    Assert-Optional (-not $local.IncidentMode -and $local.UnattendedJoinEnabled -and $local.MaxBatch -eq 100)
}
Case-Optional 'GPO désactivée ne force pas activation locale' {
    $local=[pscustomobject]@{IncidentMode=$true;UnattendedJoinEnabled=$false;UnattendedOperationsEnabled=$false;MaxBatch=20}
    $r=Merge-PestoManagedPolicy $local ([pscustomobject]@{Values=[pscustomobject]@{IncidentMode=0;DisableUnattendedJoin=0;DisableUnattendedOperations=0;MaxBatch=150}})
    Assert-Optional ($r.IncidentMode -and -not $r.UnattendedJoinEnabled -and -not $r.UnattendedOperationsEnabled -and $r.MaxBatch -eq 20)
}
Case-Optional 'GPO valeurs mal typées bloquent' {
    $local=[pscustomobject]@{IncidentMode=$false;UnattendedJoinEnabled=$false;UnattendedOperationsEnabled=$false;MaxBatch=20}
    Reject-Optional {Merge-PestoManagedPolicy $local ([pscustomobject]@{Values=[pscustomobject]@{MaxBatch=201}})}
    Reject-Optional {Merge-PestoManagedPolicy $local ([pscustomobject]@{Values=[pscustomobject]@{IncidentMode='true'}})}
}
Case-Optional 'Modèles GPO XML lisibles et références cohérentes' {
    $admx=[xml][IO.File]::ReadAllText((Join-Path $dev 'integrations/policies/Pesto.admx'))
    $adml=[xml][IO.File]::ReadAllText((Join-Path $dev 'integrations/policies/fr-FR/Pesto.adml'))
    $strings=@($adml.SelectNodes('//*[local-name()="string"]')|ForEach-Object{$_.id})
    foreach($node in $admx.SelectNodes('//*')){foreach($attribute in $node.Attributes){if($attribute.Value -match '^\$\(string\.(.+)\)$'){Assert-Optional ($Matches[1] -cin $strings)}}}
}
$report=[pscustomobject]@{Schema=1;Suite='OptionalIntegrations';HostOS=[Environment]::OSVersion.ToString();PowerShell=$PSVersionTable.PSVersion.ToString();WindowsExecuted=([Environment]::OSVersion.Platform -eq 'Win32NT');ADExecuted=$false;WPFExecuted=$false;GPOApplied=$false;Scope='Contrats et modèles XML locaux ; aucune lecture secret ni écriture réseau/registre';Total=$cases.Count;Passed=@($cases|Where-Object Passed).Count;Failed=@($cases|Where-Object{-not $_.Passed}).Count;Cases=$cases.ToArray()}
if($ReportPath){[IO.File]::WriteAllText([IO.Path]::GetFullPath($ReportPath),($report|ConvertTo-Json -Depth 8),[Text.UTF8Encoding]::new($false))}
$report|Select-Object Suite,Total,Passed,Failed|Format-Table
if($report.Failed){exit 1}

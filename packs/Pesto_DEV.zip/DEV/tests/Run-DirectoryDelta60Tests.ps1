#requires -Version 5.1
$ErrorActionPreference='Stop'
. (Join-Path (Split-Path $PSScriptRoot -Parent) 'wad/Pesto-Directory.ps1')
$n=0
function Check($ok,$message){if(-not $ok){throw $message};$script:n++}
$root='OU=Machines,DC=example,DC=test';$id=[Guid]::NewGuid().ToString('D');$other=[Guid]::NewGuid().ToString('D')
$before=[pscustomobject]@{ObjectGUID=$id;Name='PC1';DistinguishedName="CN=PC1,$root"}
$renamed=[pscustomobject]@{ObjectGUID=$id;Name='PC2';DistinguishedName="CN=PC2,$root";Deleted=$false}
$r=@(Merge-PestoDirectoryDelta @($before) @($renamed) @($root));Check ($r.Count -eq 1 -and $r[0].Name -eq 'PC2') 'Rename duplicated identity'
Check ($before.Name -eq 'PC1') 'Previous snapshot was mutated'
$r=@(Merge-PestoDirectoryDelta @($before) @([pscustomobject]@{ObjectGUID=$id;Deleted=$true}) @($root));Check ($r.Count -eq 0) 'Deletion retained'
$r=@(Merge-PestoDirectoryDelta @($before) @([pscustomobject]@{ObjectGUID=$id;Name='PC1';DistinguishedName='CN=PC1,OU=Elsewhere,DC=example,DC=test'}) @($root));Check ($r.Count -eq 0) 'Move outside scope retained'
$r=@(Merge-PestoDirectoryDelta @() @($before,$before) @($root));Check ($r.Count -eq 1) 'Duplicate GUID retained'
$refused=$false;try{Merge-PestoDirectoryDelta @($before) @([pscustomobject]@{ObjectGUID='bad';Deleted=$true}) @($root)}catch{$refused=$true};Check $refused 'Invalid GUID accepted'
$script:instance=[Guid]::NewGuid().ToString('D');$scope=($root.ToUpperInvariant()+'|'+$root.ToUpperInvariant())
$state=[pscustomobject]@{Schema=1;DC='dc.example.test';Instance=$script:instance;Scope=$scope;AuthScope='a';Cookie=[byte[]]@(1);Rows=@($before);Utc=[DateTime]::UtcNow.ToString('o')}
Check (Test-PestoDirectoryCursor $state 'dc.example.test' $script:instance $scope 'a') 'Valid cursor refused'
Check (-not(Test-PestoDirectoryCursor $state 'dc2.example.test' $script:instance $scope 'a')) 'Different DC accepted'
Check (-not(Test-PestoDirectoryCursor $state 'dc.example.test' ([Guid]::NewGuid().ToString('D')) $scope 'a')) 'Restored instance accepted'
Check (-not(Test-PestoDirectoryCursor $state 'dc.example.test' $script:instance 'changed' 'a')) 'Changed scope accepted'
Check (-not(Test-PestoDirectoryCursor $state 'dc.example.test' $script:instance $scope 'b')) 'Changed identity accepted'
$state.Utc=[DateTime]::UtcNow.AddMinutes(-16).ToString('o');Check (-not(Test-PestoDirectoryCursor $state 'dc.example.test' $script:instance $scope 'a')) 'Expired cursor accepted';$state.Utc=[DateTime]::UtcNow.ToString('o')
function Get-ADRootDSE {param($Server,$ErrorAction);[pscustomobject]@{dsServiceName='NTDS';defaultNamingContext='DC=example,DC=test'}}
function Get-ADObject {param($Identity,$Properties,$Server,$ErrorAction)
 if([string]$Identity -eq 'NTDS'){return [pscustomobject]@{invocationId=$script:instance}}
 [pscustomobject]@{ObjectGUID=$id;Name='PC2';DistinguishedName="CN=PC2,$root";ObjectClass='computer'}
}
$script:changes=@([pscustomobject]@{ObjectGUID=$id;Deleted=$false;Container=$false;UnknownClass=$true});$script:transportFail=$false;$script:seenCookie=$null
function Read-PestoDirectoryChanges {param($DC,$NamingContext,$Credential,$Cookie,$Maximum,$Cancellation)
 if($Cancellation.Cancelled){throw [OperationCanceledException]::new('cancelled')}
 if($script:transportFail){throw 'replication rights unavailable'}
 $script:seenCookie=$Cookie;[pscustomobject]@{Cookie=[byte[]]@(2);Changes=$script:changes}
}
$req=[pscustomobject]@{RootOU=$root;ScanOU=$root;AuthScope='a';SyncState=$state;Cancellation=@{Cancelled=$false}}
$r=Get-PestoIncrementalInventory $req 'dc.example.test'
Check ($null -ne $r -and $r.Root.Count -eq 1 -and $r.Root[0].Name -eq 'PC2') 'Incremental rename was not resolved'
Check ($script:seenCookie[0] -eq 1 -and $r.State.Cookie[0] -eq 2) 'Cookie was not advanced with the rows'
Check ($state.Cookie[0] -eq 1 -and $state.Rows[0].Name -eq 'PC1') 'Previous cursor/rows mutated'
$script:instance=[Guid]::NewGuid().ToString('D');$r=Get-PestoIncrementalInventory $req 'dc.example.test';Check ($script:seenCookie.Length -eq 0) 'Instance change reused cookie'
$script:instance=$state.Instance;$script:changes=@([pscustomobject]@{ObjectGUID=$other;Container=$true;Deleted=$false})
Check ($null -eq (Get-PestoIncrementalInventory $req 'dc.example.test')) 'OU change did not require full fallback'
$script:changes=@([pscustomobject]@{ObjectGUID=$id;Container=$false;Deleted=$true;UnknownClass=$true})
$r=Get-PestoIncrementalInventory $req 'dc.example.test';Check ($null -ne $r -and $r.Root.Count -eq 0) 'Deleted cached computer did not disappear'
$script:transportFail=$true;Check ($null -eq (Get-PestoIncrementalInventory $req 'dc.example.test')) 'Denied DirSync did not require full fallback'
$req.Cancellation.Cancelled=$true;$cancelled=$false;try{Get-PestoIncrementalInventory $req 'dc.example.test'}catch [OperationCanceledException]{$cancelled=$true};Check $cancelled 'Cancellation hidden by fallback'
Write-Output "DirectoryDelta60 : $n/$n PASS"

﻿#requires -Version 5.1
param()
$ErrorActionPreference='Stop';Set-StrictMode -Off
$runtime=Join-Path (Split-Path $PSScriptRoot -Parent) 'wad'
. (Join-Path $runtime 'Pesto.Engine.Runtime.ps1')
$script:passed=0;$script:failed=0
function Assert($v,$why='Assertion failed'){if(-not$v){throw $why}}
function Case($name,[scriptblock]$body){try{&$body;$script:passed++}catch{$script:failed++;Write-Host ('FAIL '+$name+': '+$_)}}
function Reject([scriptblock]$body){$caught=$false;try{&$body|Out-Null}catch{$caught=$true};Assert $caught}
$nativeSource=(Get-Command Invoke-PestoOfflineNative).Definition
$temp=Join-Path $PSScriptRoot ('pesto-effects-'+[Guid]::NewGuid().ToString('N'));[void][IO.Directory]::CreateDirectory($temp)
$script:DOMAINE='example.local';$script:DC='dc.example.local';$script:OU=@{ROOT='OU=Paris,DC=example,DC=local'};$script:OUV=@{};$script:CFG=[pscustomobject]@{};$script:SIM=$false;$script:GUI=$false
$script:PestoPolicy=[pscustomobject]@{Schema=1};$script:native=0;$script:adCalls=0;$script:writeFailure=$false;$script:nativeFailure=$false
$machine='11111111-1111-1111-1111-111111111111';$guid='22222222-2222-2222-2222-222222222222'
function Get-PestoAutomationMachineId {$machine}
function Get-PestoConfigurationSignature {param($Config);return ('a'*64)}
function Get-PestoManagedPolicy {[pscustomobject]@{Values=[pscustomobject]@{}}}
function Get-PestoCampaignPolicy {return $null}
function Get-ADParams {return @{}}
$script:fixtureLedgerRoot=Join-Path $temp 'ledger';[void][IO.Directory]::CreateDirectory($script:fixtureLedgerRoot)
function Get-PestoInterventionRoot {return $script:fixtureLedgerRoot}
function Get-PestoOfflineStore {return $temp}
function Get-PestoAutomationStore {return $temp}
function Get-PestoOperatorSid {return 'S-1-5-21-222'}
function Get-ADComputer {param($Identity,$Properties,$ErrorAction);return $script:pc}
function Set-ADObject {param($Identity,$Replace,$Clear,$ErrorAction);$script:adCalls++;Assert ($script:ActiveIntervention.Attributes -eq 'Requested');if($script:nativeFailure){throw 'fixture interruption'};foreach($k in $Replace.Keys){$script:pc.$k=$Replace[$k]};foreach($k in $Clear){$script:pc.$k=''}}
function Assert-PestoStoredMutationReady {param($Plan)}
function Write-PestoJoinReceipt {param($Path,$Receipt);if($script:writeFailure){throw 'fixture disk failure'};Write-PestoAtomicText $Path ($Receipt|ConvertTo-Json -Depth 12)}
function Reset-PC {foreach($path in [IO.Directory]::GetFiles($script:fixtureLedgerRoot)){[IO.File]::Delete($path)};$script:pc=[pscustomobject]@{Name='P111301AA765001';ObjectGUID=$guid;DistinguishedName='CN=P111301AA765001,OU=Paris,DC=example,DC=local';description='old';location='old place';managedBy='';userAccountControl=4096};$script:adCalls=0;$script:nativeFailure=$false;$script:writeFailure=$false}
try{
 Reset-PC
 Case 'Preview has exact diff and makes no mutation' {$script:plan=New-PestoAttributePlan ([Guid]$guid) ([pscustomobject]@{description='new';location=''});Assert ($script:plan.Changes.Count -eq 2);Assert ($script:plan.Changes[0].Before -eq 'old');Assert ($script:adCalls -eq 0)}
 Case 'Unknown AD attribute rejected' {Reject {New-PestoAttributePlan ([Guid]$guid) ([pscustomobject]@{userAccountControl='0'})}}
 Case 'Foreign managedBy refused before reference lookup' {Reject {New-PestoAttributePlan ([Guid]$guid) ([pscustomobject]@{managedBy='CN=X,DC=other,DC=local'})}}
 Case 'Stale before value refuses mutation' {$script:pc.description='someone else';$r=Invoke-PestoAttributeMutation $script:plan;Assert ($r.ExitCode -eq 96 -and $script:adCalls -eq 0);Reset-PC}
 Case 'Replaced GUID refuses mutation' {$script:pc.ObjectGUID=[Guid]::NewGuid();$r=Invoke-PestoAttributeMutation $script:plan;Assert ($r.ExitCode -eq 96 -and $script:adCalls -eq 0);Reset-PC}
 Case 'Persistence failure prevents AD write' {$script:writeFailure=$true;$r=Invoke-PestoAttributeMutation $script:plan;Assert ($script:adCalls -eq 0 -and $r.ExitCode -eq 96);Reset-PC}
 Case 'Replace and clear sent once, then observed' {$r=Invoke-PestoAttributeMutation $script:plan;Assert ($r.ExitCode -eq 0 -and $r.State -eq 'Verified') $r.Message;Assert ($script:adCalls -eq 1 -and $script:pc.description -eq 'new' -and $script:pc.location -eq '');Assert ((Read-PestoIntervention (Join-Path $script:fixtureLedgerRoot ($r.OperationId+'.json'))).Attributes -eq 'Confirmed');$script:attributeOp=$r.OperationId}
 Case 'Observation never repeats a Set-ADObject' {$r=Get-PestoAttributeObservation ([Guid]$script:attributeOp);Assert ($r.State -eq 'Verified' -and $script:adCalls -eq 1 -and -not $r.ReplayAllowed)}
 Case 'Divergent observation returns a nonzero code without mutation' {$script:pc.description='external';$r=Get-PestoAttributeObservation ([Guid]$script:attributeOp);Assert ($r.State -eq 'Uncertain' -and $r.ExitCode -eq 97 -and $script:adCalls -eq 1)}
 Case 'Native failure is uncertain, not retried' {Reset-PC;$script:nativeFailure=$true;$r=Invoke-PestoAttributeMutation $script:plan;Assert ($r.ExitCode -eq 97 -and $script:adCalls -eq 1 -and $r.MutationStarted);$again=Invoke-PestoAttributeMutation $script:plan;Assert ($again.ExitCode -eq 96 -and $script:adCalls -eq 1);Reset-PC}
 Case 'Tampered diff rejected even with unchanged plan checksum' {$p=$script:plan|ConvertTo-Json -Depth 10|ConvertFrom-Json;$p.Changes[0].After='altered';$r=Invoke-PestoAttributeMutation $p;Assert ($r.ExitCode -eq 96 -and $script:adCalls -eq 0)}
 # DPAPI and djoin are transport doubles only; no native Windows call or AD connection.
 function Protect-PestoOfflineBytes {param([byte[]]$Bytes);return ,([byte[]]@($Bytes|ForEach-Object{$_ -bxor 42}))}
 function Unprotect-PestoOfflineBytes {param([byte[]]$Bytes);return ,([byte[]]@($Bytes|ForEach-Object{$_ -bxor 42}))}
 $script:local=[pscustomobject]@{Computer='P111301AA765001';PartOfDomain=$false;PendingRename=$false;Admin=$true;DomainRole=0;MachineId=$machine;BootUtc='2026-10-17T10:00:00Z';Domain='WORKGROUP'}
 function Get-PestoJoinLocalStatus {return $script:local}
 function Invoke-PestoOfflineNative {param($Path);$script:native++;$id=[IO.Path]::GetFileName($Path).Replace('.odj.tmp','');$r=Read-PestoOfflineRecord $id;Assert ($r.State -eq 'Requested') 'Intent must precede native call';Assert ([IO.File]::ReadAllText($Path) -like 'fixture-*');if($script:nativeFailure){throw 'fixture native interruption'};return 0}
 function Import-PestoADModule {param($ADModulePath)}
 function Get-DomainController {param($Domain);return 'dc.example.local'}
 function Test-ComputerSecureChannel {param($Server,$ErrorAction);return $script:secure}
 $source=Join-Path $temp 'source.blob';[IO.File]::WriteAllText($source,'fixture-secret-one')
 Case 'Import protects secret and exports only its hash' {$script:import=Import-PestoOfflineBlob $source ([Guid]$guid) $script:OU.ROOT;Assert ($script:import.State -eq 'Imported');$paths=Get-PestoOfflinePaths $script:import.BlobId;Assert (-not [IO.File]::ReadAllText($paths.State).Contains('fixture-secret'));Assert (-not [IO.File]::ReadAllText($paths.Secret).Contains('fixture-secret'));Assert ([IO.File]::Exists($source))}
 Case 'Same blob cannot be reimported' {Reject {Import-PestoOfflineBlob $source ([Guid]$guid) $script:OU.ROOT}}
 Case 'Wrong current machine name prevents ODJ' {$script:local.Computer='OTHER';Reject {Invoke-PestoOfflineApply $script:import.BlobId};Assert ($script:native -eq 0);$script:local.Computer='P111301AA765001'}
 Case 'Durable intent precedes single native application' {$r=Invoke-PestoOfflineApply $script:import.BlobId;Assert ($r.ExitCode -eq 3010 -and $r.State -eq 'PendingRestart' -and $script:native -eq 1);$paths=Get-PestoOfflinePaths $script:import.BlobId;Assert (-not [IO.File]::Exists($paths.Plain) -and -not [IO.File]::Exists($paths.Secret))}
 Case 'Repeated request does not call djoin' {$r=Invoke-PestoOfflineApply $script:import.BlobId;Assert ($r.ExitCode -eq 97 -and $script:native -eq 1)}
 Case 'No reboot is not a successful observation' {$r=Get-PestoOfflineObservation $script:import.BlobId $runtime $null;Assert ($r.State -eq 'Uncertain')}
 $script:local.PartOfDomain=$true;$script:local.Domain=$script:DOMAINE;$script:local.BootUtc='2026-10-18T10:00:00Z';$script:secure=$false
 Case 'Broken secure channel remains uncertain' {$r=Get-PestoOfflineObservation $script:import.BlobId $runtime $null;Assert ($r.State -eq 'Uncertain' -and -not $r.SecureChannel)}
 $script:secure=$true
 Case 'GUID, reboot, domain and channel reconcile existing receipt' {$r=Get-PestoOfflineObservation $script:import.BlobId $runtime $null;Assert ($r.State -eq 'Verified' -and $script:native -eq 1);Assert ((Read-PestoOfflineRecord $script:import.BlobId).State -eq 'Verified');$saved=Read-PestoIntervention (Join-Path $script:fixtureLedgerRoot ($r.OperationId+'.json'));Assert ($saved.OfflineJoin -eq 'Verified' -and $saved.Phase -eq 'Verified')}
 $script:local.PartOfDomain=$false;$script:nativeFailure=$true;[IO.File]::WriteAllText($source,'fixture-secret-two')
 Case 'Interrupted application has persistent no-replay state and no plaintext' {$i=Import-PestoOfflineBlob $source ([Guid]$guid) $script:OU.ROOT;Reject {Invoke-PestoOfflineApply $i.BlobId};Assert ((Read-PestoOfflineRecord $i.BlobId).State -eq 'Uncertain');$n=$script:native;[void](Invoke-PestoOfflineApply $i.BlobId);Assert ($script:native -eq $n);Assert (-not [IO.File]::Exists((Get-PestoOfflinePaths $i.BlobId).Plain))}
 Case 'ODJ effect is isolated from online join' {$fn=(Get-Command Invoke-PestoOfflineApply).Definition;Assert (-not $fn.Contains('Add-Computer') -and -not $fn.Contains('AddToDomain'));Assert ($nativeSource.Contains('/requestodj'))}
}finally{[IO.Directory]::Delete($temp,$true)}
Write-Host "ExtensionEffects: $script:passed passed, $script:failed failed. Real receipt lifecycle and schema; AD/DPAPI/djoin/ACL transports mocked; no VM."
if($script:failed){exit 1}

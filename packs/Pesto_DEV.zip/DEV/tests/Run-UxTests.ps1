﻿#requires -Version 5.1
[CmdletBinding()]
param([string]$ReportPath='')
# Windows PowerShell 5.1 : $PSScriptRoot est vide dans les valeurs par défaut des paramètres (vu le 03/10).
if(-not $ReportPath){$ReportPath=Join-Path $PSScriptRoot 'windows-ui-results.json'}
$ErrorActionPreference='Stop'
Set-StrictMode -Off
if($env:OS -ne 'Windows_NT' -or $PSVersionTable.PSEdition -ne 'Desktop' -or $PSVersionTable.PSVersion.Major -ne 5 -or -not [Environment]::Is64BitProcess){throw 'Tests interface : Windows PowerShell 5.1 x64 requis.'}
if([Threading.Thread]::CurrentThread.ApartmentState -ne 'STA'){throw 'Exécuter cette suite avec powershell.exe -STA.'}
Add-Type -AssemblyName PresentationFramework,PresentationCore,WindowsBase,System.Xml,System.Data
$root=[IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..'))
$path=Join-Path $root 'wad\Pesto-Core.ps1'
# Fenêtre principale dans Pesto-Shell.xaml, chargée comme le fait le moteur (Get-Content puis [xml]).
$shellPath=Join-Path $root 'wad\Pesto-Shell.xaml'
$source=Get-Content -LiteralPath $path -Raw -Encoding UTF8
$results=[Collections.Generic.List[object]]::new()
$script:UiErrors=[Collections.Generic.List[string]]::new()
$script:ForbiddenCalls=0;$script:SourceReads=0;$script:PrefsWrites=0
$temp=Join-Path ([IO.Path]::GetTempPath()) ('Pesto-UI-'+[Guid]::NewGuid().ToString('N'))
[void][IO.Directory]::CreateDirectory($temp)
function Assert-True {param($Condition,[string]$Message='Assertion non satisfaite.');if(-not $Condition){throw $Message}}
function Equal {param($Actual,$Expected);if($Actual -ne $Expected){throw "Attendu : '$Expected', obtenu : '$Actual'."}}
function Case {param([string]$Name,[scriptblock]$Body)
    try{& $Body;$results.Add([pscustomobject]@{Name=$Name;Passed=$true;Skipped=$false;Error=''});Write-Host "OK  $Name"}
    catch{$results.Add([pscustomobject]@{Name=$Name;Passed=$false;Skipped=$false;Error=$_.Exception.Message});Write-Host "KO  $Name : $($_.Exception.Message)"}
}
# Palettes : même méthode que Run-LoginTests.ps1. $script:Themes est lu dans l'arbre du parseur,
# sans évaluation ; seules des tables imbriquées de chaînes '#RRGGBB' ou '#AARRGGBB' sont acceptées.
function Get-LiteralExpression {
    param([Management.Automation.Language.Ast]$Node)
    if($Node -is [Management.Automation.Language.PipelineAst]){return $Node.GetPureExpression()}
    if($Node -is [Management.Automation.Language.CommandExpressionAst]){return $Node.Expression}
    return $Node
}
function Get-LiteralKey {
    param([Management.Automation.Language.Ast]$Node,[string]$Where)
    if(-not($Node -is [Management.Automation.Language.StringConstantExpressionAst]) -or -not $Node.Value){
        throw ('Clé non littérale dans '+$Where+' : '+$Node.Extent.Text)
    }
    return [string]$Node.Value
}
function Read-ThemePalettes {
    param([Management.Automation.Language.Ast]$Ast,[string]$Where)
    $themeNodes=@($Ast.FindAll({
        param($Candidate)
        ($Candidate -is [Management.Automation.Language.AssignmentStatementAst]) -and
        ([string]$Candidate.Operator -eq 'Equals') -and
        ($Candidate.Left -is [Management.Automation.Language.VariableExpressionAst]) -and
        ($Candidate.Left.VariablePath.UserPath -eq 'script:Themes' -or $Candidate.Left.Extent.Text -eq '$script:Themes')
    },$true))
    if($themeNodes.Count -ne 1){throw ('Affectation $script:Themes introuvable ou ambiguë dans '+$Where+' ('+$themeNodes.Count+').')}
    $themeTable=Get-LiteralExpression $themeNodes[0].Right
    if(-not($themeTable -is [Management.Automation.Language.HashtableAst])){throw 'Palettes non littérales : aucune évaluation du moteur.'}
    $found=@{}
    foreach($themePair in $themeTable.KeyValuePairs){
        $themeName=Get-LiteralKey $themePair.Item1 '$script:Themes'
        $colorTable=Get-LiteralExpression $themePair.Item2
        if(-not($colorTable -is [Management.Automation.Language.HashtableAst])){throw ('Palette non littérale : '+$themeName)}
        $colors=@{}
        foreach($colorPair in $colorTable.KeyValuePairs){
            $colorKey=Get-LiteralKey $colorPair.Item1 $themeName
            $colorValue=Get-LiteralExpression $colorPair.Item2
            if(-not($colorValue -is [Management.Automation.Language.StringConstantExpressionAst]) -or
               -not [regex]::IsMatch([string]$colorValue.Value,'\A#([0-9A-Fa-f]{6}|[0-9A-Fa-f]{8})\z')){
                throw ('Couleur non littérale ou invalide : '+$themeName+'.'+$colorKey)
            }
            if($colors.ContainsKey($colorKey)){throw ('Couleur dupliquée : '+$themeName+'.'+$colorKey)}
            $colors[$colorKey]=[string]$colorValue.Value
        }
        if($found.ContainsKey($themeName)){throw ('Palette dupliquée : '+$themeName)}
        $found[$themeName]=$colors
    }
    foreach($required in @('Light','Dark')){
        if(-not $found.ContainsKey($required) -or $found[$required].Count -lt 1){throw ('Palette absente : '+$required)}
    }
    # Une clé absente d'un thème laisserait le pinceau Light du Shell en place, sans erreur WPF.
    $lightKeys=[Collections.Generic.HashSet[string]]::new([StringComparer]::Ordinal)
    foreach($colorKey in $found['Light'].Keys){[void]$lightKeys.Add([string]$colorKey)}
    $darkKeys=[Collections.Generic.HashSet[string]]::new([StringComparer]::Ordinal)
    foreach($colorKey in $found['Dark'].Keys){[void]$darkKeys.Add([string]$colorKey)}
    if(-not $lightKeys.SetEquals($darkKeys)){throw 'Palettes Light et Dark incohérentes.'}
    return $found
}
function Assert-Palette {
    # Chaque couleur de la palette doit être le pinceau effectif de la fenêtre après Set-Theme.
    param([string]$Name)
    $palette=$script:Themes[$Name]
    Assert-True ($palette -and $palette.Count -gt 0) ('Palette absente : '+$Name)
    foreach($paletteKey in $palette.Keys){
        $expected=([Windows.Media.Color][Windows.Media.ColorConverter]::ConvertFromString([string]$palette[$paletteKey])).ToString()
        $brush=$Win.Resources[$paletteKey]
        if(-not($brush -is [Windows.Media.SolidColorBrush]) -or $brush.Color.ToString() -ne $expected){
            throw ($Name+'.'+$paletteKey+' : attendu '+$expected+', obtenu '+[string]$brush)
        }
    }
}
# Moteur et composants qu'il dot-source : lus comme texte, puis analysés par le parseur. Rien n'est exécuté.
$engineFiles=[Collections.Generic.List[string]]::new();$engineFiles.Add('Pesto-Core.ps1')
foreach($componentHit in [regex]::Matches($source,'(?m)^[ \t]*\.[ \t]+\(Join-Path[ \t]+\$PSScriptRoot[ \t]+''(Pesto-[A-Za-z]+\.ps1)''\)')){
    $componentName=$componentHit.Groups[1].Value
    if(-not $engineFiles.Contains($componentName)){$engineFiles.Add($componentName)}
}
# Les fonctions testees ne sont plus toutes dot-sourcées par le moteur : le banc indexe tout wad/,
# sans quoi il meurt au chargement sur « Fonction requise absente ». Extension exacte : '-Filter *.ps1'
# attrape aussi les .ps1xml sous Windows (mesuré 29 fichiers pour 27 .ps1).
# L'agrégat CLI généré recopie les fonctions sources : il ne fait pas partie du chargement GUI.
foreach($file in (Get-ChildItem -LiteralPath (Join-Path $root 'wad') -File | Where-Object{$_.Extension -eq '.ps1' -and $_.Name -ine 'Pesto.Engine.Runtime.ps1'} | Sort-Object Name)){
    if(-not $engineFiles.Contains($file.Name)){$engineFiles.Add($file.Name)}
}
$engineAst=@{};$parseIssues=[Collections.Generic.List[string]]::new()
$defs=@{};$defFiles=@{}
foreach($engineFile in $engineFiles){
    $engineText=if($engineFile -eq 'Pesto-Core.ps1'){$source}else{Get-Content -LiteralPath (Join-Path $root ('wad\'+$engineFile)) -Raw -Encoding UTF8}
    $engineTokens=$null;$engineErrors=$null
    $engineAst[$engineFile]=[Management.Automation.Language.Parser]::ParseInput($engineText,[ref]$engineTokens,[ref]$engineErrors)
    foreach($engineError in $engineErrors){$parseIssues.Add($engineFile+' : '+$engineError.Message)}
    foreach($d in $engineAst[$engineFile].EndBlock.Statements){
        if($d -is [Management.Automation.Language.FunctionDefinitionAst]){
            if($defs.ContainsKey($d.Name)){$parseIssues.Add('Fonction définie deux fois : '+$d.Name+' ('+$defFiles[$d.Name]+', '+$engineFile+')')}
            else{$defs[$d.Name]=$d;$defFiles[$d.Name]=$engineFile}
        }
    }
}
Case 'Parseur PowerShell natif du moteur et de ses composants' {Assert-True ($parseIssues.Count -eq 0) ($parseIssues -join '; ')}
if($parseIssues.Count){throw 'Le moteur ne peut pas être parsé sans ambiguïté. Aucun chargement de Pesto.'}
# Seules les définitions ci-dessous sont chargées. Le corps de Pesto n'est JAMAIS exécuté.
$load=@('Test-PestoDnsName','Get-PestoDomainFromDN','Test-PestoDNWithinScope','Test-PestoComputerName','Test-PestoGeneratedComputerName','Test-PestoOUPath','Split-PestoDistinguishedName','Get-PestoNameSiteCode','Get-PestoSiteContainerDN','Get-PestoRenameMoveDecision',
 'Test-PestoOptionalPostCheckReceipt','Test-PestoAcknowledgedReceipt','Assert-PestoJoinReceiptData','Assert-PestoClosedObject','ConvertTo-PestoDeploymentMetadata','Test-PestoPropertyPresent','Get-PestoHistoryEmptyText','Get-PestoNameSegments','ConvertTo-PestoNameParts','Get-PestoNamingResolutionNonce','Get-PestoDefaultNamingConvention','Assert-PestoNamingConvention','Set-PestoActiveNamingConvention','Get-PestoActiveNamingConvention','Get-PestoNamingLayout','Get-PestoNameLength','Get-PestoNameMaximumNumber','New-PestoComputerName','New-PestoNameSeries','Format-PestoNameNumber','New-PestoNameFromSeries','Get-PestoNameSeriesBase','Get-PestoNameNumber','Test-PestoNameSeries','Get-PestoNamingFunctionNames','Get-PestoFacetPattern','New-PestoNameLdapPattern','Format-PestoOUForDisplay','Sync-PestoAppearanceControls','ConvertTo-PestoUiZoomPercent','Get-PestoZoomViewportLayout','Get-PestoUiLayoutSize','Update-PestoUiZoomLayout','Get-PestoHomeReceiptSummary','Get-PestoHomeDashboard','Update-PestoHomeDashboard','Get-PestoCachedComputerProbe','ConvertTo-PestoInterventionRow','Get-PestoStatePresentation','Get-PestoStageLabel','Get-PestoEffectLabel','Set-PestoSuiteMode','Set-PestoSuiteHelp',
 'Get-PestoUxSnapshot','New-QueueTable','Format-OUPath','New-Brush','New-ThemeIcon','Set-Theme','Set-OULabel','Reset-ConfigFields','Update-FieldColor',
 'Request-PestoUxRefresh','Invoke-PestoUxRefreshTick','Invoke-PestoUxInputChanged','Update-PestoUx','Update-PestoUxLayout','Invoke-PestoUxSizeChanged',
 'Set-PestoUxPage','Sync-PestoUxNavigation','Invoke-PestoUxNavigate','Invoke-PestoUxPageChanged','Request-PestoPageAutomationRefresh','Update-PestoPageAutomationPeers','Update-PestoUxHistory','Invoke-PestoUxHistoryRefresh',
 'Set-PestoUxTechnicalColumns','Invoke-PestoUxTechnicalChanged','Invoke-PestoUxCopyName','Request-PestoUxComputerLookup','Invoke-PestoUxComputerLookupTick',
 'Invoke-PestoUxReadComputer','Invoke-PestoUxSourceKey','Invoke-PestoUxKey','Initialize-PestoUx','Stop-PestoUx','Invoke-DoEvents','ConvertTo-PestoHighContrastPalette','Get-PestoUxNom')
foreach($name in $load){if(-not $defs.ContainsKey($name)){throw "Fonction requise absente : $name"};. ([scriptblock]::Create($defs[$name].Extent.Text))}
# Get-PestoUxNom lit $script:PESTO_UX_NOMS, table littérale de Pesto-UXFlow.ps1. Le banc ne dot-source
# aucune ligne de produit : il évalue cette seule affectation, reprise depuis l'AST et vérifiée littérale.
$uxNamesAst=$null
foreach($stmt in $engineAst['Pesto-UXFlow.ps1'].EndBlock.Statements){
    if($stmt -is [Management.Automation.Language.AssignmentStatementAst] -and $stmt.Left.Extent.Text -eq '$script:PESTO_UX_NOMS'){$uxNamesAst=$stmt}
}
if(-not $uxNamesAst){throw 'Affectation $script:PESTO_UX_NOMS absente de Pesto-UXFlow.ps1.'}
if($uxNamesAst.Right.Extent.Text -notmatch '^(\[ordered\])?@\{'){throw 'Affectation $script:PESTO_UX_NOMS non littérale : le banc refuse d''évaluer du code du moteur.'}
. ([scriptblock]::Create($uxNamesAst.Extent.Text))
# Doubles explicitement isolés : pas de compte, pas de module AD et pas de moteur.
function Test-PestoAsyncOperationRunning {param([string]$Name);return $false}
function Stop-PestoAsyncOperation {param([string]$Name)}
function Test-PestoGlobalSafetyBarrier {return [bool]$script:MutationUncertain}
function Select-PCName {$script:SourceReads++}
function Save-Prefs {$script:PrefsWrites++}
function Restyle-Chips {}
function Render-Log {}
function Update-NameGrid {}
function Update-PestoJoinUI {}
function Update-PestoHomeInterventions {}
function Request-PestoJoinInventory {$script:JoinInventoryRequests++}
function Request-PestoJoinSiteLookup {$script:JoinSiteLookupRequests++}
# Bandeau de suite non initialisé ($script:SuiteReady=$false) : les fonctions réelles ne feraient rien ici.
function Update-PestoSuiteUI {}
function Update-PestoSuiteLayout {}
function Write-Log {param($Message,$Level,$ErrorObject,$Area);if($Level -eq 'ERROR'){$script:UiErrors.Add([string]$Message)}}
function Show-MsgWarning {param($Message);throw "Dialogue inattendu : $Message"}
function Show-MsgInfo {param($Message);throw "Dialogue inattendu : $Message"}
function Show-PestoTextReport {param($Title,$Text)}
function Get-PestoStateDirectory {return $temp}
function Rename-Computer {$script:ForbiddenCalls++;throw 'Mutation interdite dans cette suite.'}
function Add-Computer {$script:ForbiddenCalls++;throw 'Mutation interdite dans cette suite.'}
function Move-ADObject {$script:ForbiddenCalls++;throw 'Mutation interdite dans cette suite.'}
function Get-ADComputer {$script:ForbiddenCalls++;throw 'Accès AD interdit dans cette suite.'}
function Refresh-Names {$script:ForbiddenCalls++;throw 'Inventaire AD interdit dans cette suite.'}
function Run-Queue {$script:ForbiddenCalls++;throw 'Exécution de file interdite dans cette suite.'}
function Pump {param([int]$Ms=130);$until=[DateTime]::UtcNow.AddMilliseconds($Ms);while([DateTime]::UtcNow -lt $until){Invoke-DoEvents;Start-Sleep -Milliseconds 10}}
# Actualisations UIA comptées sur la vraie fonction du moteur, jamais redéfinie par le banc : point d'arrêt à action,
# comme Run-SharedNameReservationTests.ps1. Sans break ni continue dans l'action, l'exécution ne s'arrête pas.
$script:UxAutomationUpdates=0
$script:UxAutomationBreakpoint=Set-PSBreakpoint -Command 'Update-PestoPageAutomationPeers' -Action {$script:UxAutomationUpdates++}
function Get-UxAutomationIds {param($Peer)
    $todo=[Collections.Generic.Queue[object]]::new();$todo.Enqueue($Peer);$seen=[Collections.Generic.HashSet[object]]::new()
    while($todo.Count){$entry=$todo.Dequeue();if(-not $seen.Add($entry)){continue};$id=$entry.GetAutomationId();if($id){$id};foreach($child in @($entry.GetChildren())){if($child){$todo.Enqueue($child)}}}
}
function Start-StaleLookup {
    # Le moteur n'arme plus la lecture différée à la saisie (lecture par Lire ou Entrée) ; sa garde reste testée.
    $script:PestoUxLookupName=([string]$TxtPCName.Text).Trim().ToUpperInvariant()
    $script:PestoUxLookupEditIndex=[int]$script:EDIT_ROW_INDEX
    $script:PestoUxLookupLocal=[bool]$script:LOCALHOST
    $script:PestoUxLookupTimer.Start()
}
[xml]$xml=Get-Content -LiteralPath $shellPath -Raw -Encoding UTF8
if(-not $xml -or $xml.DocumentElement.LocalName -ne 'Window'){throw 'XAML principal introuvable.'}
$manager=[Xml.XmlNamespaceManager]::new($xml.NameTable);$manager.AddNamespace('x','http://schemas.microsoft.com/winfx/2006/xaml')
$manager.AddNamespace('p','http://schemas.microsoft.com/winfx/2006/xaml/presentation')
$publicXPath='//*[@x:Name and not(ancestor::p:ControlTemplate) and not(ancestor::p:DataTemplate) and not(ancestor::p:ItemsPanelTemplate)]'
$Win=$null
try{
    Case 'Chargement réel de la fenêtre XAML et de ses ressources' {$script:Win=[Windows.Markup.XamlReader]::Load([Xml.XmlNodeReader]::new($xml));Assert-True ($null -ne $Win)}
    if(-not $Win){throw 'Chargement WPF impossible. Aucun test de navigation lancé.'}
    Case 'Table des libellés UX chargée depuis l''AST du moteur' {
        Assert-True ($script:PESTO_UX_NOMS.Count -gt 0) 'Table des libellés vide.'
        Assert-True ((Get-PestoUxNom 'PagePoste').Length -gt 0) 'Libellé vide.'
        $lues=0;foreach($node in $xml.SelectNodes($publicXPath,$manager)){
            $controlName=$node.GetAttribute('Name','http://schemas.microsoft.com/winfx/2006/xaml')
            if($script:PESTO_UX_NOMS.Contains($controlName)){$lues++}
        }
        Assert-True ($lues -gt 0) 'Aucun nom public du Shell couvert par la table des libellés.'
    }
    foreach($node in $xml.SelectNodes($publicXPath,$manager)){
        $n=$node.GetAttribute('Name','http://schemas.microsoft.com/winfx/2006/xaml');Set-Variable -Name $n -Value $Win.FindName($n) -Scope Script
    }
    Case 'Les contrôles publics du Shell sont uniques et résolus par FindName' {
        $seen=[Collections.Generic.HashSet[string]]::new([StringComparer]::Ordinal)
        foreach($node in $xml.SelectNodes($publicXPath,$manager)){
            $controlName=$node.GetAttribute('Name','http://schemas.microsoft.com/winfx/2006/xaml')
            Assert-True ($seen.Add($controlName)) ('Nom public dupliqué : '+$controlName)
            Assert-True ($null -ne $Win.FindName($controlName)) $node.OuterXml
        }
        Assert-True ($seen.Count -gt 0) 'Aucun contrôle public.'
    }
    $script:Themes=@{}
    Case 'Palettes Light et Dark lues dans $script:Themes sans exécuter le moteur' {
        $script:Themes=Read-ThemePalettes $engineAst['Pesto-Core.ps1'] $path
        foreach($paletteKey in $script:Themes['Light'].Keys){Assert-True ($Win.Resources[$paletteKey] -is [Windows.Media.SolidColorBrush]) ('Pinceau absent du Shell : '+$paletteKey)}
    }
    $script:table=New-QueueTable;$Grid.ItemsSource=$script:table.DefaultView
    $script:INDOMAIN=$true;$script:LOCALHOST=$false;$script:GUI=$true;$script:SIM=$false
    $script:DOMAINE='TEST.LOCAL';$script:PREFIXE='111301';$script:OU=@{};$script:OUV=@{};$script:EDIT_ROW_INDEX=-1;$script:Suspend=$false
    $script:Running=$false;$script:PreflightRunning=$false;$script:MutationUncertain=$false;$script:CfgRestartRequired=$false
    $script:Computers=@();$script:PestoUxReady=$false;$script:PCProbeGeneration=0
    $script:ThemeMode='Light';$script:SuiteReady=$false;$script:SuiteMode='Single';$script:DirectBusy=$false
    $script:HelpVisible=$false;$script:NavigationCollapsed=$false;$script:InventoryLoaded=$false
    $sourceOU='OU=Windows11,OU=PR,OU=Postes,DC=test,DC=local'
    $targetOU='OU=Windows11,OU=VA,OU=Postes,DC=test,DC=local'
    $fixture=@{Computer='P111301PR765129';NewName='P111301VA765010';CurrentOU=$sourceOU;TargetOU=$targetOU;Rename=$true;Move=$false;Reboot=$false;InDomain=$true;CanAdd=$true;Service='765';Site='VA';Type='Portable'}
    Case 'PR vers VA : aperçu renommer puis déplacer' {$v=Get-PestoUxSnapshot @fixture;Equal $v.Operation 'Renommer puis déplacer';Equal $v.FutureOU $targetOU;Assert-True $v.Move}
    Case 'Même site : conserver l''OU actuelle malgré une autre OU proposée' {$f=$fixture.Clone();$f.Computer='P111301VA765129';$v=Get-PestoUxSnapshot @f;Equal $v.Operation 'Renommer seulement';Equal $v.FutureOU $sourceOU;Assert-True (-not $v.Move)}
    Case 'Même site, changement de service : aucun déplacement' {$f=$fixture.Clone();$f.NewName='P111301PR123010';$v=Get-PestoUxSnapshot @f;Assert-True (-not $v.Move);Equal $v.FutureOU $sourceOU}
    Case 'Déplacement seul : nom source conservé' {$f=$fixture.Clone();$f.Rename=$false;$f.Move=$true;$v=Get-PestoUxSnapshot @f;Equal $v.Operation 'Déplacer seulement';Equal $v.FinalName $f.Computer;Equal $v.FutureOU $targetOU}
    Case 'Redémarrage non demandé par défaut' {Equal (Get-PestoUxSnapshot @fixture).RebootText 'Redémarrage : non demandé'}
    Case 'Redémarrage explicite correctement présenté' {$f=$fixture.Clone();$f.Reboot=$true;Equal (Get-PestoUxSnapshot @f).RebootText 'Redémarrage : demandé après réussite'}
    Case 'Hors domaine : aperçu de jonction locale' {$f=$fixture.Clone();$f.InDomain=$false;$v=Get-PestoUxSnapshot @f;Equal $v.Operation 'Joindre ce PC au domaine';Equal $v.FutureOU $targetOU}
    Case 'Verrou de sécurité expliqué sans être effacé' {$f=$fixture.Clone();$f.SafetyLocked=$true;$v=Get-PestoUxSnapshot @f;Assert-True ($v.NextStep -like 'Verrou de sécurité*')}
    Case 'Nom occupé expliqué' {$f=$fixture.Clone();$f.NameTaken=$true;$f.CanAdd=$false;Assert-True ((Get-PestoUxSnapshot @f).AddHint -like 'Ce nom est déjà pris*')}
    Case 'Lecture source en cours explique l''attente' {$f=$fixture.Clone();$f.Reading=$true;Equal (Get-PestoUxSnapshot @f).Stage 1}
    Case 'Étape 4 réservée au traitement effectivement en cours' {$f=$fixture.Clone();$f.Running=$true;Equal (Get-PestoUxSnapshot @f).Stage 4}
    Case 'Contrôle AD reste en étape 3 sans annoncer une mutation' {$f=$fixture.Clone();$f.Preflight=$true;Equal (Get-PestoUxSnapshot @f).Stage 3}
    Case 'Aides des commandes désactivées activées dans WPF' {
        foreach($control in @($BtnAdd,$BtnRun,$BtnStop,$BtnRetryMove,$CbSite,$CbName)){
            Assert-True ([Windows.Controls.ToolTipService]::GetShowOnDisabled($control)) $control.Name
            Assert-True (-not [string]::IsNullOrWhiteSpace([string]$control.ToolTip)) $control.Name
        }
    }
    Case 'Tous les contrôles interactifs publics possèdent une aide' {
        foreach($node in $xml.SelectNodes($publicXPath,$manager)){
            $name=$node.GetAttribute('Name','http://schemas.microsoft.com/winfx/2006/xaml');$c=$Win.FindName($name)
            if($c -is [Windows.Controls.Primitives.ButtonBase] -or $c -is [Windows.Controls.TextBox] -or $c -is [Windows.Controls.ComboBox] -or $c -is [Windows.Controls.DataGrid]){
                Assert-True (-not [string]::IsNullOrWhiteSpace([string]$c.ToolTip)) "Aide absente : $name"
                Assert-True (-not [string]::IsNullOrWhiteSpace([Windows.Automation.AutomationProperties]::GetHelpText($c))) "HelpText absent : $name"
            }
        }
    }
    Case 'Colonnes simples : exactement six colonnes visibles' {Set-PestoUxTechnicalColumns $false;Equal @($Grid.Columns|Where-Object{$_.Visibility -eq 'Visible'}).Count 6}
    Case 'Colonnes techniques réversibles et liaisons conservées' {Set-PestoUxTechnicalColumns $true;Equal @($Grid.Columns|Where-Object{$_.Visibility -eq 'Visible'}).Count $Grid.Columns.Count;Set-PestoUxTechnicalColumns $false;Equal @($Grid.Columns|Where-Object{$_.Visibility -eq 'Visible'}).Count 6}
    Case 'Thème clair appliqué par le véritable Set-Theme' {Set-Theme 'Light';Assert-Palette 'Light';Equal $script:CurrentTheme 'Light'}
    Case 'Thème sombre appliqué aux mêmes ressources' {Set-Theme 'Dark';Assert-Palette 'Dark';Equal $script:CurrentTheme 'Dark'}
    Case 'Initialisation des événements sans closure privée' {Initialize-PestoUx;Assert-True $script:PestoUxReady;Pump}
    # Fenêtre WPF hors écran et transparente pour mesurer/arranger réellement les contrôles.
    # Ni login, ni moteur, ni module AD ne sont chargés par ces tests.
    # Le HWND reste borné par l'écran de CI. Pour les trois cas de disposition ci-dessous,
    # détacher le véritable arbre XAML, puis Measure/Arrange à la taille explicite en DIP.
    # Les fonctions de disposition sont les fonctions produit : aucune largeur logique simulée.
    # Ce contrôle de layout n'est ni une capture 1460 px ni une validation du DPI physique.
    $script:UxEcran=[int][Windows.SystemParameters]::PrimaryScreenWidth
    $script:UxRendu=0
    $script:UxLayoutMeasurements=[Collections.Generic.List[object]]::new()
    function Show-UxHorsEcran {param([int]$Largeur)
        $Win.ShowInTaskbar=$false;$Win.Opacity=0;$Win.WindowStartupLocation='Manual';$Win.Left=-12000;$Win.Top=-12000
        $Win.Width=$Largeur;$Win.Height=940;$Win.Show();Pump 180;$Win.UpdateLayout();Update-PestoUxLayout
        return [int]$Win.ActualWidth
    }
    Case 'Fenêtre affichée hors écran : mise en page réellement rendue' {$script:UxRendu=Show-UxHorsEcran 1460;Assert-True ($Win.ActualWidth -gt 0);Assert-True ($BodyGrid.ActualWidth -gt 0)}
    $detachedHost=$Win.Content
    $detachedWidth=$detachedHost.Width;$detachedHeight=$detachedHost.Height
    $Win.Content=$null;$Win.UpdateLayout();Pump
    if([Windows.Media.VisualTreeHelper]::GetParent($detachedHost)){throw 'Le ContentPresenter natif conserve encore le viewport du banc.'}
    [void]$detachedHost.Resources.MergedDictionaries.Add($Win.Resources)
    # WPF suspend le layout des visuels retirés ; un nouveau parent actif le reprend.
    $detachedSurface=[Windows.Controls.Border]::new();$detachedSurface.Child=$detachedHost
    function Arrange-UxDetached {param([double]$Width,[double]$Height)
        # Sans parent natif, UpdateLayout réévalue une racine Auto selon DesiredSize.
        # Fixer le viewport réel du banc, sans remplacer les fonctions produit.
        $detachedHost.Width=$Width;$detachedHost.Height=$Height
        $detachedSurface.Width=$Width;$detachedSurface.Height=$Height
        for($pass=0;$pass -lt 6;$pass++){
            $detachedSurface.Measure([Windows.Size]::new($Width,$Height))
            $detachedSurface.Arrange([Windows.Rect]::new(0,0,$Width,$Height))
            $detachedHost.UpdateLayout();Update-PestoUxLayout
        }
        $logical=Get-PestoUiLayoutSize
        $script:UxLayoutMeasurements.Add([pscustomobject]@{RequestedWidth=$Width;RequestedHeight=$Height;ActualWidth=$detachedHost.ActualWidth;ActualHeight=$detachedHost.ActualHeight;LogicalWidth=$logical.Width;PreviewColumn=[Windows.Controls.Grid]::GetColumn($PreviewPanel);PreviewRow=[Windows.Controls.Grid]::GetRow($PreviewPanel)})
        Assert-True ([Math]::Abs($detachedHost.ActualWidth-$Width) -lt 0.1) ('Arbre XAML : demandé={0}, arrangé={1}, logique={2}.' -f $Width,$detachedHost.ActualWidth,$logical.Width)
        Assert-True ($BodyGrid.ActualWidth -gt 0 -and $BtnRun.ActualHeight -ge 36)
    }
    try{
        Case 'Layout XAML isolé à 1460 x 940 DIP : aperçu à droite' {Arrange-UxDetached 1460 940;Equal ([Windows.Controls.Grid]::GetColumn($PreviewPanel)) 2;Equal ([Windows.Controls.Grid]::GetRow($PreviewPanel)) 0;Equal $FormSplitter.Visibility 'Visible'}
        Case 'Layout XAML isolé à 1100 x 940 DIP : aperçu sous le formulaire' {Arrange-UxDetached 1100 940;Equal ([Windows.Controls.Grid]::GetColumn($PreviewPanel)) 0;Equal ([Windows.Controls.Grid]::GetRow($PreviewPanel)) 1;Equal $FormSplitter.Visibility 'Collapsed'}
        Case 'Layout XAML isolé : retour à 1460 DIP avec les mêmes contrôles' {Arrange-UxDetached 1460 940;Equal ([Windows.Controls.Grid]::GetColumn($PreviewPanel)) 2;Equal ([Windows.Controls.Grid]::GetRow($PreviewPanel)) 0;Equal $FormSplitter.Visibility 'Visible'}
    }finally{
        $detachedSurface.Child=$null
        [void]$detachedHost.Resources.MergedDictionaries.Remove($Win.Resources)
        $detachedHost.Width=$detachedWidth;$detachedHost.Height=$detachedHeight
        $Win.Content=$detachedHost;$Win.Width=1100;Pump;Update-PestoUxLayout;$Win.UpdateLayout()
    }
    Case 'Fenêtre native compacte : aperçu sous le formulaire' {Equal ([Windows.Controls.Grid]::GetColumn($PreviewPanel)) 0;Equal ([Windows.Controls.Grid]::GetRow($PreviewPanel)) 1;Equal $FormSplitter.Visibility 'Collapsed'}
    Case 'ComboBox non éditable : menu contractuel présent' {[void]$CbSite.ApplyTemplate();Assert-True ($null -ne $CbSite.Template.FindName('PART_Popup',$CbSite))}
    Case 'ComboBox éditable : vrai champ de saisie conservé' {[void]$CbService.ApplyTemplate();Assert-True ($CbService.Template.FindName('PART_EditableTextBox',$CbService) -is [Windows.Controls.TextBox])}
    Case 'Navigation par vrais événements WPF' {
        foreach($pair in @(@($NavHome,4),@($NavRename,0),@($NavNames,1),@($NavHistory,5),@($NavLogs,3),@($NavSettings,2),@($NavHelp,6),@($NavJoin,7))){
            $pair[0].RaiseEvent([Windows.RoutedEventArgs]::new([Windows.Controls.Primitives.ButtonBase]::ClickEvent))
            Equal $MainTabs.SelectedIndex $pair[1]
        }
        Equal $script:SuiteMode 'Single'
        Set-PestoUxPage 'Rename'
    }
    Case 'Deux cents cycles de navigation gardent les mêmes contrôles et un seul timer UX' {
        $tabsBefore=$MainTabs;$timerBefore=$script:PestoUxTimer;$lookupBefore=$script:PestoUxLookupTimer
        for($cycle=0;$cycle -lt 200;$cycle++){
            foreach($pair in @(@($NavHome,4),@($NavRename,0),@($NavNames,1),@($NavSettings,2))){
                $pair[0].RaiseEvent([Windows.RoutedEventArgs]::new([Windows.Controls.Primitives.ButtonBase]::ClickEvent))
                Equal $MainTabs.SelectedIndex $pair[1]
            }
            Initialize-PestoUx
        }
        Assert-True ([object]::ReferenceEquals($tabsBefore,$MainTabs))
        Assert-True ([object]::ReferenceEquals($timerBefore,$script:PestoUxTimer))
        Assert-True ([object]::ReferenceEquals($lookupBefore,$script:PestoUxLookupTimer))
        Set-PestoUxPage 'Rename';Pump;Equal $script:ForbiddenCalls 0
    }
    Case 'UIA : aucun pair créé lorsque personne ne consulte l''accessibilité' {
        Pump;$before=$script:UxAutomationUpdates
        $MainTabs=[Windows.Controls.TabControl]::new()
        Assert-True ($null -eq [Windows.Automation.Peers.UIElementAutomationPeer]::FromElement($MainTabs))
        Request-PestoPageAutomationRefresh;Assert-True (-not $script:PestoPageAutomationPending) 'Actualisation UIA planifiée sans pair.';Pump
        Assert-True ($null -eq [Windows.Automation.Peers.UIElementAutomationPeer]::FromElement($MainTabs));Equal $script:UxAutomationUpdates $before
    }
    Case 'UIA : les changements de page exposent le contenu courant en conservant les pairs' {
        Set-PestoUxPage 'Home';Pump
        $script:UxWindowPeer=[Windows.Automation.Peers.UIElementAutomationPeer]::CreatePeerForElement($Win)
        $script:UxMainPeer=[Windows.Automation.Peers.UIElementAutomationPeer]::CreatePeerForElement($MainTabs)
        [void](Get-UxAutomationIds $script:UxWindowPeer)
        foreach($pair in @(@('Rename','CbSite'),@('Home','HomePrepare'),@('Rename','CbSite'),@('Home','HomePrepare'))){
            Set-PestoUxPage $pair[0];Pump;$Win.UpdateLayout()
            Assert-True ($pair[1] -in @(Get-UxAutomationIds $script:UxWindowPeer)) ('Contenu UIA absent : '+$pair[1])
            Assert-True ([object]::ReferenceEquals($script:UxMainPeer,[Windows.Automation.Peers.UIElementAutomationPeer]::FromElement($MainTabs)))
            Assert-True ([object]::ReferenceEquals($script:UxWindowPeer,[Windows.Automation.Peers.UIElementAutomationPeer]::FromElement($Win)))
        }
    }
    Case 'UIA : dix demandes avant le rendu produisent une seule actualisation différée' {
        Pump;$before=$script:UxAutomationUpdates
        1..10|ForEach-Object{Request-PestoPageAutomationRefresh}
        Assert-True $script:PestoPageAutomationPending;Equal $script:UxAutomationUpdates $before
        Pump;Equal $script:UxAutomationUpdates ($before+1);Assert-True (-not $script:PestoPageAutomationPending)
    }
    Case 'UIA : changer les sous-onglets ne reconstruit pas les enfants de MainTabs' {
        Set-PestoUxPage 'Rename';Pump;$before=$script:UxAutomationUpdates
        $tabs=$Win.FindName('QueueToolTabs');foreach($index in @(1,2,0,2)){$tabs.SelectedIndex=$index}
        Assert-True (-not $script:PestoPageAutomationPending) 'Actualisation UIA demandée par un sous-onglet.';Pump
        Equal $MainTabs.SelectedIndex 0;Equal $script:UxAutomationUpdates $before
    }
    # X5 : anneaux d'état lus dans les vrais gabarits WPF. Couleurs système de contraste élevé simulées (Noir) ;
    # le rendu à l'écran reste à vérifier sur une capture Windows en contraste élevé.
    Case 'X5 contraste élevé : anneaux du menu actif, de l''onglet actif et de l''élément survolé, transparents en clair et sombre' {
        $hc=@{Window='#000000';WindowText='#FFFFFF';Highlight='#1AEBFF';HighlightText='#000000';ButtonFace='#000000';ButtonText='#FFFFFF';HotTrack='#FFFF00'}
        $script:Themes['HighContrast']=ConvertTo-PestoHighContrastPalette -Keys @($script:Themes['Light'].Keys) -System $hc
        $themeBefore=$script:CurrentTheme
        $probe=[Windows.Controls.ComboBoxItem]::new();$probe.Content='Sonde X5'
        $setHighlighted=[Windows.Controls.ComboBoxItem].GetProperty('IsHighlighted').GetSetMethod($true)
        $ringColor={
            param($Control,[string]$Part)
            [void]$Control.ApplyTemplate()
            $ring=$Control.Template.FindName($Part,$Control)
            Assert-True ($ring -is [Windows.Controls.Border]) ('Anneau absent : '+$Part)
            if($ring.BorderBrush -is [Windows.Media.SolidColorBrush]){return $ring.BorderBrush.Color.ToString()}
            return 'aucun'
        }
        try{
            Set-PestoUxPage 'Settings';$SetTabs.SelectedIndex=0;[void]$SuiteThemeChoiceHost.Children.Add($probe);Pump;$Win.UpdateLayout()
            foreach($theme in @('Light','Dark','HighContrast')){
                Set-Theme $theme;Assert-Palette $theme;Pump;$Win.UpdateLayout()
                [void]$setHighlighted.Invoke($probe,[object[]]@($true));$probe.IsSelected=$false
                $hover=& $ringColor $probe 'ComboItemState'
                $probe.IsSelected=$true
                $hoverSelected=& $ringColor $probe 'ComboItemState'
                [void]$setHighlighted.Invoke($probe,[object[]]@($false))
                $selectedOnly=& $ringColor $probe 'ComboItemState'
                $probe.IsSelected=$false
                $found=[ordered]@{
                    'menu actif'=(& $ringColor $NavSettings 'ButtonState');'onglet actif'=(& $ringColor $SetTabs.Items[0] 'InnerTabState')
                    'élément survolé'=$hover;'élément survolé et sélectionné'=$hoverSelected
                    'menu inactif'=(& $ringColor $NavHome 'ButtonState');'onglet inactif'=(& $ringColor $SetTabs.Items[1] 'InnerTabState')
                    'élément sélectionné non survolé'=$selectedOnly;'élément au repos'=(& $ringColor $probe 'ComboItemState')
                }
                # Contraste élevé : surlignage (Highlight), texte de surlignage sur un élément déjà sélectionné. Sinon : transparent.
                $wantRing=if($theme -eq 'HighContrast'){'#FF1AEBFF'}else{'#00000000'};$wantOnSelection=if($theme -eq 'HighContrast'){'#FF000000'}else{'#00000000'}
                $want=@{'menu actif'=$wantRing;'onglet actif'=$wantRing;'élément survolé'=$wantRing;'élément survolé et sélectionné'=$wantOnSelection}
                foreach($state in @($found.Keys)){
                    $expected=if($want.ContainsKey($state)){$want[$state]}else{'aucun'}
                    Assert-True ($found[$state] -eq $expected) ($theme+', '+$state+' : attendu '+$expected+', obtenu '+$found[$state])
                }
            }
        }finally{[void]$SuiteThemeChoiceHost.Children.Remove($probe);Set-Theme $themeBefore;Set-PestoUxPage 'Rename'}
    }
    Case 'Bouton Aide : panneau basculé et mémorisé, page conservée' {
        $page=$MainTabs.SelectedIndex;$writes=$script:PrefsWrites
        $BtnHelp.RaiseEvent([Windows.RoutedEventArgs]::new([Windows.Controls.Primitives.ButtonBase]::ClickEvent))
        Assert-True ([bool]$script:HelpVisible) 'Aide non affichée.'
        $BtnHelp.RaiseEvent([Windows.RoutedEventArgs]::new([Windows.Controls.Primitives.ButtonBase]::ClickEvent))
        Assert-True (-not $script:HelpVisible) 'Aide non refermée.'
        Equal $MainTabs.SelectedIndex $page;Equal ($script:PrefsWrites-$writes) 2
    }
    Case 'Historique vide clairement expliqué' {Update-PestoUxHistory;Assert-True ($UxHistoryMessage.Text -like 'Aucun lot terminé*')}
    Case 'Historique d''un autre domaine refusé' {
        [IO.File]::WriteAllText((Join-Path $temp 'history-v1.json'),'{"Schema":1,"Domain":"OTHER.LOCAL","Entries":[]}')
        Update-PestoUxHistory;Assert-True ($UxHistoryMessage.Text -like 'Historique non chargé*')
        Remove-Item -LiteralPath (Join-Path $temp 'history-v1.json') -Force
    }
    Case 'La recherche invalide immédiatement l''ancien plan' {
        $generation=[int]$script:PCProbeGeneration
        $TxtPCName.Text='P111301PR765129';$BtnAdd.IsEnabled=$true;Request-PestoUxComputerLookup
        Assert-True (-not $BtnAdd.IsEnabled) 'Ajout encore possible.';Equal $script:PCProbeGeneration ($generation+1)
        Assert-True (-not $script:PestoUxLookupTimer.IsEnabled) 'Lecture différée armée par la saisie.'
    }
    Case 'Saisies rapides : aucune lecture du poste sans demande explicite' {
        $before=$script:SourceReads
        Request-PestoUxComputerLookup;Request-PestoUxComputerLookup;Request-PestoUxComputerLookup
        Pump 450;Equal ($script:SourceReads-$before) 0
    }
    Case 'Lecture différée au même contexte : une seule lecture' {
        $before=$script:SourceReads;Start-StaleLookup
        # Minuteur de 350 ms : sur un bureau chargé, le tick peut arriver tard. Attendre qu'il se déclenche (2 s au plus),
        # puis laisser passer un intervalle de plus : exactement une lecture, minuteur arrêté.
        $until=[DateTime]::UtcNow.AddSeconds(2);while(($script:SourceReads-$before) -lt 1 -and [DateTime]::UtcNow -lt $until){Pump 50}
        Pump 450;Equal ($script:SourceReads-$before) 1;Assert-True (-not $script:PestoUxLookupTimer.IsEnabled) 'Timer de lecture resté actif.'
    }
    Case 'Demande temporisée abandonnée après changement de ligne éditée' {
        Start-StaleLookup;$before=$script:SourceReads;$script:EDIT_ROW_INDEX=3
        Pump 450;Equal $script:SourceReads $before;$script:EDIT_ROW_INDEX=-1
    }
    Case 'Demande temporisée abandonnée après changement local/distant' {
        Start-StaleLookup;$before=$script:SourceReads;$script:LOCALHOST=-not $script:LOCALHOST
        Pump 450;Equal $script:SourceReads $before;$script:LOCALHOST=-not $script:LOCALHOST
    }
    Case 'Bouton de lecture : une lecture, sans préparer ni lancer de ligne' {
        $before=$script:table.Rows.Count;$reads=$script:SourceReads;Invoke-PestoUxReadComputer $null $null
        Equal $script:table.Rows.Count $before;Equal ($script:SourceReads-$reads) 1;Equal $script:ForbiddenCalls 0
    }
    Case 'Touche Entrée : lecture du poste seulement' {
        $before=$script:table.Rows.Count;$reads=$script:SourceReads
        $keyEvent=[pscustomobject]@{Key=[Windows.Input.Key]::Return;Handled=$false}
        Invoke-PestoUxSourceKey $TxtPCName $keyEvent
        Assert-True $keyEvent.Handled 'Touche Entrée non consommée.';Equal ($script:SourceReads-$reads) 1;Equal $script:table.Rows.Count $before
    }
    Case 'Verrou de sécurité : aucune lecture du poste' {
        $reads=$script:SourceReads;$script:MutationUncertain=$true
        try{Invoke-PestoUxReadComputer $null $null}finally{$script:MutationUncertain=$false}
        Equal $script:SourceReads $reads
    }
    Case 'Fermeture arrête les deux timers UI' {Stop-PestoUx;Assert-True (-not $script:PestoUxTimer.IsEnabled);Assert-True (-not $script:PestoUxLookupTimer.IsEnabled)}
    Case 'Aucune mutation ni lecture AD pendant les tests UI' {Equal $script:ForbiddenCalls 0}
    Case 'Aucune exception masquée par le rafraîchissement d''aperçu' {Equal $script:UiErrors.Count 0}
}finally{
    if($script:UxAutomationBreakpoint){Remove-PSBreakpoint -Breakpoint $script:UxAutomationBreakpoint}
    if($Win){try{Stop-PestoUx;$Win.Close()}catch{}}
    if(Test-Path -LiteralPath $temp){Remove-Item -LiteralPath $temp -Recurse -Force}
    $failed=@($results|Where-Object{-not $_.Passed})
    $skipped=@($results|Where-Object{$_.Skipped})
    $report=[ordered]@{Suite='Pesto interface (fenêtre principale isolée)';Utc=[DateTime]::UtcNow.ToString('o');SourceHash=(Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash;
        ShellHash=(Get-FileHash -LiteralPath $shellPath -Algorithm SHA256).Hash;EngineFiles=$engineFiles.ToArray();TestSha256=(Get-FileHash -LiteralPath $PSCommandPath -Algorithm SHA256).Hash;
        EngineSourceHashes=@($engineFiles|ForEach-Object{[pscustomobject]@{Name=$_;Sha256=(Get-FileHash -LiteralPath (Join-Path (Join-Path $root 'wad') $_) -Algorithm SHA256).Hash}});
        PowerShell=$PSVersionTable.PSVersion.ToString();OperatingSystem=[Environment]::OSVersion.VersionString;Culture=[Globalization.CultureInfo]::CurrentCulture.Name;UICulture=[Globalization.CultureInfo]::CurrentUICulture.Name;ClrVersion=[Environment]::Version.ToString();
        PhysicalViewportWidth=$script:UxEcran;NativeWindowWidth=$script:UxRendu;IsolatedLayoutMeasurements=$script:UxLayoutMeasurements.ToArray();
        Total=$results.Count;Passed=$results.Count-$failed.Count-$skipped.Count;Failed=$failed.Count;Skipped=$skipped.Count;NotTested=@($skipped|ForEach-Object{$_.Name});Tests=$results.ToArray();
        Scope='Fenêtre WPF isolée (Pesto-Shell.xaml), mise en page hors écran et arbre XAML détaché à tailles DIP explicites (aucune preuve de résolution ou DPI physique), palettes de $script:Themes, événements, aides, fonctions extraites du moteur et de ses composants. Aucun login, accès AD, mutation ni validation visuelle manuelle.'}
    $report|ConvertTo-Json -Depth 7|Set-Content -LiteralPath $ReportPath -Encoding UTF8
}
if($failed.Count){exit 1}
if($skipped.Count){Write-Host "Tests UI isolés réussis, $($skipped.Count) cas non testés sur ce viewport (nom et mesure dans windows-ui-results.json) : consulter les limites consignées dans le rapport."}
else{Write-Host 'Tests UI isolés réussis. Effectuer aussi une recette visuelle et un test sur des postes non critiques.'}
exit 0

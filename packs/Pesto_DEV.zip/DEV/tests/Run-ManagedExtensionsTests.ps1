﻿#requires -Version 5.1
param()
$ErrorActionPreference='Stop';Set-StrictMode -Off
$root=Split-Path $PSScriptRoot -Parent
foreach($f in @('Contracts','Configuration','ManagedPolicy','Policy','Enterprise')){. (Join-Path $root ('wad/Pesto-'+$f+'.ps1'))}
$script:passed=0;$script:failed=0
function Case($name,[scriptblock]$body){try{&$body;$script:passed++}catch{$script:failed++;Write-Host ('FAIL '+$name+': '+$_)}}
function Assert($v){if(-not$v){throw 'Assertion failed'}}
function Reject([scriptblock]$body){$caught=$false;try{&$body|Out-Null}catch{$caught=$true};Assert $caught}
$s=[pscustomobject]@{Schema=1;Name='Paris';Required=@('Type','ServiceCode');Allowed=[pscustomobject]@{Type=@('P','V');SiteCode=@('AA')};Locked=[pscustomobject]@{ServiceCode='765'}}
$v=[pscustomobject]@{Type='P';SiteCode='AA';ServiceCode='765';TargetOU='OU=Paris,DC=example,DC=local'}
Case 'Valid scenario' {Assert-PestoScenarioValues $s $v}
Case 'Required field absent' {$c=$v.PSObject.Copy();$c.Type='';Reject {Assert-PestoScenarioValues $s $c}}
Case 'Disallowed type' {$c=$v.PSObject.Copy();$c.Type='S';Reject {Assert-PestoScenarioValues $s $c}}
Case 'Locked field changed' {$c=$v.PSObject.Copy();$c.ServiceCode='766';Reject {Assert-PestoScenarioValues $s $c}}
Case 'Unknown rule refused' {$c=$s.PSObject.Copy();$c|Add-Member Extra $true;Reject {ConvertTo-PestoScenario $c}}
Case 'Contradictory rule refused' {$c=$s.PSObject.Copy();$c.Locked=[pscustomobject]@{Type='S'};Reject {ConvertTo-PestoScenario $c}}
Case 'GPO scenario overrides local' {$p=ConvertTo-PestoPolicy ([pscustomobject]@{Schema=1}) -LocalOnly;$m=Merge-PestoManagedPolicy $p ([pscustomobject]@{Values=[pscustomobject]@{Scenario=$s}});Assert ($m.Scenario.Name -eq 'Paris')}
Case 'Engine derives fields from actual name' {$p=[pscustomobject]@{Nouveau_Nom='V111301AA765001';OU_Destination=$v.TargetOU};Assert-PestoScenarioValues $s (Get-PestoPlanScenarioValues $p);$p.Nouveau_Nom='S111301AA765001';Reject {Assert-PestoScenarioValues $s (Get-PestoPlanScenarioValues $p)}}
$script:sid='S-1-5-21-111';function Get-PestoOperatorSid {$script:sid};function Get-PestoAutomationMachineId {'fixture-machine'}
$rsa=[Security.Cryptography.RSA]::Create(2048)
$request=[Security.Cryptography.X509Certificates.CertificateRequest]::new('CN=Pesto fixture',$rsa,[Security.Cryptography.HashAlgorithmName]::SHA256,[Security.Cryptography.RSASignaturePadding]::Pkcs1)
$cert=$request.CreateSelfSigned([DateTimeOffset]::UtcNow.AddDays(-1),[DateTimeOffset]::UtcNow.AddDays(1))
$script:policy=[pscustomobject]@{Campaigns=@('C42');Signers=@([pscustomobject]@{CertificateSHA256=(Get-PestoBytesHash $cert.RawData);Sid=$script:sid})}
function Get-PestoCampaignPolicy {$script:policy}
$p=New-PestoPortablePlan -Action Rename -Computer 'PC001' -NewName 'P111301AA765001' -Domain 'example.local' -ConfigStamp ('a'*64) -MachineId 'fixture-machine' -SourceOU $v.TargetOU -TargetOU $v.TargetOU -ObjectGuid '11111111-1111-1111-1111-111111111111' -Metadata ([pscustomobject]@{Campaign='C42'})
try{
 $approval=New-PestoCampaignApproval @($p) $cert
 Case 'Self approval refused' {Reject {Assert-PestoCampaignApproval $p $approval}}
 $script:sid='S-1-5-21-222'
 Case 'Independent signed approval' {Assert-PestoCampaignApproval $p $approval}
 Case 'Changed effect refused' {$c=$p.PSObject.Copy();$c.NewName='P111301AA765002';Reject {Assert-PestoCampaignApproval $c $approval}}
 Case 'Changed identity refused' {$c=$p.PSObject.Copy();$c.ObjectGuid='22222222-2222-2222-2222-222222222222';Reject {Assert-PestoCampaignApproval $c $approval}}
 Case 'Changed machine refused' {$c=$p.PSObject.Copy();$c.MachineId='other';Reject {Assert-PestoCampaignApproval $c $approval}}
 Case 'Missing approval refused' {Reject {Assert-PestoCampaignApproval $p $null}}
 Case 'Invalid signature refused' {$c=$approval.PSObject.Copy();$b=[Convert]::FromBase64String($c.Signature);$b[0]=$b[0] -bxor 1;$c.Signature=[Convert]::ToBase64String($b);Reject {Assert-PestoCampaignApproval $p $c}}
 Case 'Expired but correctly signed approval refused' {
    $c=$approval.PSObject.Copy();$payload=[Text.Encoding]::UTF8.GetString([Convert]::FromBase64String($c.Payload))|ConvertFrom-Json
    $payload.CreatedUtc=[DateTime]::UtcNow.AddHours(-2).ToString('o');$payload.ExpiresUtc=[DateTime]::UtcNow.AddHours(-1).ToString('o')
    $bytes=[Text.Encoding]::UTF8.GetBytes(($payload|ConvertTo-Json -Depth 5 -Compress));$c.Payload=[Convert]::ToBase64String($bytes)
    $c.Signature=[Convert]::ToBase64String($rsa.SignData($bytes,[Security.Cryptography.HashAlgorithmName]::SHA256,[Security.Cryptography.RSASignaturePadding]::Pkcs1))
    Reject {Assert-PestoCampaignApproval $p $c}
 }
 Case 'Payload tampering refused before claims are trusted' {$c=$approval.PSObject.Copy();$b=[Convert]::FromBase64String($c.Payload);$b[5]=$b[5] -bxor 1;$c.Payload=[Convert]::ToBase64String($b);Reject {Assert-PestoCampaignApproval $p $c}}
 Case 'Revocation by removing signer' {$old=$script:policy.Signers;$script:policy.Signers=@();try{Reject {Assert-PestoCampaignApproval $p $approval}}finally{$script:policy.Signers=$old}}
 Case 'Execution and exported effect share digest' {$execution=[pscustomobject]@{Renommer=$true;Deplacer=$false;Nom_du_PC=$p.Computer;Nouveau_Nom=$p.NewName;OU_Actuelle=$p.SourceOU;OU_Destination=$p.TargetOU;Objet_GUID=$p.ObjectGuid;TargetOUGuid=$p.TargetOUGuid;Domain=$p.Domain;ConfigStamp=$p.ConfigStamp;Metadata=$p.Metadata};Assert ((Get-PestoCampaignPlanHash $execution) -ceq (Get-PestoCampaignPlanHash $p));Assert-PestoCampaignApproval $execution $approval}
 Case 'Unselected campaign remains optional' {$c=$p.PSObject.Copy();$c.Metadata=[pscustomobject]@{Campaign='Other'};Assert-PestoCampaignApproval $c $null}
 Case 'Wildcard requires campaign for all operations' {$old=$script:policy.Campaigns;$script:policy.Campaigns=@('*');try{$c=$p.PSObject.Copy();$c.Metadata=$null;Reject {Assert-PestoCampaignApproval $c $null}}finally{$script:policy.Campaigns=$old}}
}finally{$cert.Dispose();$rsa.Dispose()}
Write-Host "ManagedExtensions: $script:passed passed, $script:failed failed (no Windows/AD/VM calls)."
if($script:failed){exit 1}

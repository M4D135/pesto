#requires -Version 5.1
$ErrorActionPreference='Stop';$root=Split-Path $PSScriptRoot -Parent;$wad=Join-Path $root 'wad'
. (Join-Path $wad 'Pesto-Common.ps1')
Initialize-PestoRuntimeTypes -Root $wad
$n=0
function Check($ok,$message){if(-not $ok){throw $message};$script:n++}
foreach($name in @('Pesto.Runtime.AsyncAuditWriter','Pesto.Inventory.CompactIndex','Pesto.NativePipe17','Pesto.NativeShell')){
 $type=$name -as [type];Check ($null -ne $type -and $type.Assembly.GetName().Name -ceq 'Pesto.Runtime') ('Wrong helper provenance: '+$name)
}
$a=[Pesto.Inventory.CompactIndex].Assembly;Initialize-PestoRuntimeTypes -Root $wad
Check ([object]::ReferenceEquals($a,[Pesto.Inventory.CompactIndex].Assembly)) 'Repeated load duplicated assembly'
Check ($a.GetCustomAttributesData().Where({$_.AttributeType.Name -eq 'TargetFrameworkAttribute'})[0].ConstructorArguments[0].Value -eq '.NETFramework,Version=v4.7.2') 'Wrong target framework'
$temp=Join-Path ([IO.Path]::GetTempPath()) ('PestoCompiled-'+[Guid]::NewGuid().ToString('N'));[void][IO.Directory]::CreateDirectory($temp)
try{
 $bytes=[IO.File]::ReadAllBytes((Join-Path $wad 'Pesto.Runtime.dll'));$bytes[$bytes.Length-1]=$bytes[$bytes.Length-1] -bxor 1
 [IO.File]::WriteAllBytes((Join-Path $temp 'Pesto.Runtime.dll'),$bytes)
 $refused=$false;try{Initialize-PestoRuntimeTypes -Root $temp}catch{$refused=$true};Check $refused 'Tampered DLL accepted'
 $file=Join-Path $temp 'audit.log';[IO.File]::WriteAllText($file,'');$writer=[Pesto.Runtime.AsyncAuditWriter]::new($file,128)
 try{
  Check ($writer.TryWrite('verified-runtime')) 'Compiled writer rejected data'
  Check ($writer.Flush(2000)) 'Compiled writer did not flush'
  Check ([IO.File]::ReadAllText($file) -eq 'verified-runtime') 'Compiled writer changed data'
 }finally{[void]$writer.Close(2000)}
}finally{Remove-Item -LiteralPath $temp -Recurse -Force}

# Surface native : les entrees DllImport livrees sont la liste exacte a qualifier sur cible.
function Get-NativeSurface{
 param([string[]]$TypeNames)
 $found=[Collections.Generic.List[string]]::new()
 foreach($t in $TypeNames){
  $type=$t -as [type];if(-not $type){throw 'Native helper type missing: '+$t}
  foreach($m in $type.GetMethods([Reflection.BindingFlags]::Public -bor [Reflection.BindingFlags]::Static)){
   foreach($attr in @($m.GetCustomAttributesData())){
    if($attr.AttributeType.Name -ceq 'DllImportAttribute'){[void]$found.Add($t+'|'+[string]$attr.ConstructorArguments[0].Value+'|'+$m.Name)}
   }
  }
 }
 return $found.ToArray()
}
$expectedNative=@('Pesto.NativeShell|shell32.dll|SetCurrentProcessExplicitAppUserModelID','Pesto.NativeShell|user32.dll|SendMessage','Pesto.NativeShell|user32.dll|DestroyIcon','Pesto.NativePipe17|kernel32.dll|GetNamedPipeClientProcessId')
$observedNative=@(Get-NativeSurface -TypeNames @('Pesto.Runtime.AsyncAuditWriter','Pesto.Inventory.CompactIndex','Pesto.NativePipe17','Pesto.NativeShell'))
$nativeDrift=@(Compare-Object -ReferenceObject $expectedNative -DifferenceObject $observedNative)
Check ($nativeDrift.Count -eq 0) ('Native surface drifted from the on-target qualification list: '+(($nativeDrift|ForEach-Object {$_.SideIndicator+' '+$_.InputObject}) -join '; '))

function Parse-ShippedFile{
 param([string]$Path)
 if(-not (Test-Path -LiteralPath $Path)){throw 'Shipped file missing: '+$Path}
 $tokens=$null;$errors=$null
 $ast=[Management.Automation.Language.Parser]::ParseFile($Path,[ref]$tokens,[ref]$errors)
 if(@($errors).Count){throw 'Unparsable shipped file: '+$Path}
 return $ast
}
function Find-NativeCalls{
 param($Ast,[string]$TypeName,[string]$MemberName)
 $target=if($MemberName){[regex]::Escape($MemberName)}else{'\w+'}
 $pattern='^\['+[regex]::Escape($TypeName)+'\]::'+$target+'\s*\('
 return @($Ast.FindAll({param($n) $n -is [Management.Automation.Language.InvokeMemberExpressionAst] -and $n.Extent.Text -match $pattern},$true))
}
# Porte du canal eleve : l'appel natif kernel32 est en defaillance securisante avant tout secret.
function Assert-PipeGateFailClosed{
 param([string]$Path,[string]$Label)
 $ast=Parse-ShippedFile -Path $Path
 $gate=@($ast.FindAll({param($n) $n -is [Management.Automation.Language.FunctionDefinitionAst] -and $n.Name -ceq 'Test-PestoPipeClient'},$true))
 Check ($gate.Count -eq 1) ('Pipe gate function missing in '+$Label)
 $gateFn=$gate[0]
 Check (@($gateFn.FindAll({param($n) $n -is [Management.Automation.Language.CommandAst] -and $n.GetCommandName() -ceq 'Initialize-PestoRuntimeTypes'},$true)).Count -eq 1) ('Pipe gate no longer loads the verified library in '+$Label)
 $calls=Find-NativeCalls -Ast $gateFn -TypeName 'Pesto.NativePipe17' -MemberName 'GetNamedPipeClientProcessId'
 Check ($calls.Count -eq 1) ('Native pipe call count changed in '+$Label)
 $node=$calls[0].Parent;$guard=$null
 while($node -and $node -ne $gateFn){if($node -is [Management.Automation.Language.IfStatementAst]){$guard=$node;break};$node=$node.Parent}
 $negated='^if\s*\(\s*-not\s'+[regex]::Escape($calls[0].Extent.Text)+'\s*\)'
 Check ($null -ne $guard -and $guard.Extent.Text -cmatch $negated) ('Native pipe call no longer negated in '+$Label)
 Check (@($guard.FindAll({param($n) $n -is [Management.Automation.Language.ThrowStatementAst]},$true)).Count -ge 1) ('Native pipe failure no longer throws in '+$Label)
 Check (@($gateFn.FindAll({param($n) $n -is [Management.Automation.Language.ThrowStatementAst] -and $n.Extent.Text -cmatch 'Aucun secret transmis'},$true)).Count -ge 1) ('Unexpected-client throw lost in '+$Label)
 $callers=@($ast.FindAll({param($n) $n -is [Management.Automation.Language.CommandAst] -and $n.GetCommandName() -ceq 'Test-PestoPipeClient'},$true))
 $caller=$null
 foreach($c in $callers){$f=$c;while($f -and $f -isnot [Management.Automation.Language.FunctionDefinitionAst]){$f=$f.Parent};if($f -and $f.Name -cne 'Test-PestoPipeClient'){$caller=$c;break}}
 Check ($null -ne $caller) ('No elevated-flow pipe gate caller in '+$Label)
 $fn=$caller;while($fn -and $fn -isnot [Management.Automation.Language.FunctionDefinitionAst]){$fn=$fn.Parent}
 $creds=@($fn.FindAll({param($n) $n -is [Management.Automation.Language.InvokeMemberExpressionAst] -and $n.Extent.Text -match 'GetNetworkCredential\s*\('},$true))
 Check ($creds.Count -ge 1 -and $caller.Extent.StartLineNumber -lt $creds[0].Extent.StartLineNumber) ('Pipe gate no longer precedes the secret in '+$Label)
}
# Chemin icone : les appels natifs user32/shell32 restent souples (garde de type, within try).
function Assert-IconPathSoft{
 param([string]$Path,[string]$Label)
 $ast=Parse-ShippedFile -Path $Path
 $calls=Find-NativeCalls -Ast $ast -TypeName 'Pesto.NativeShell' -MemberName ''
 Check ($calls.Count -eq 5) ('NativeShell call count changed in '+$Label)
 foreach($c in $calls){
  $node=$c;$inTry=$false
  while($node){if($node -is [Management.Automation.Language.TryStatementAst]){$inTry=$true;break};$node=$node.Parent}
  Check $inTry ('Unguarded native icon call at line '+$c.Extent.StartLineNumber+' in '+$Label)
 }
 $fn=@($ast.FindAll({param($n) $n -is [Management.Automation.Language.FunctionDefinitionAst] -and $n.Name -ceq 'Set-WindowIcon'},$true))
 Check ($fn.Count -eq 1) ('Icon function missing in '+$Label)
 Check (@([regex]::Matches($fn[0].Extent.Text,[regex]::Escape("'Pesto.NativeShell' -as [type]"))).Count -ge 2) ('NativeShell type guards missing in '+$Label)
}
Assert-PipeGateFailClosed -Path (Join-Path $wad 'Pesto-Operations.ps1') -Label 'wad/Pesto-Operations.ps1'
Assert-PipeGateFailClosed -Path (Join-Path $wad 'Pesto.Engine.Runtime.ps1') -Label 'module Engine genere'
Assert-IconPathSoft -Path (Join-Path $wad 'Pesto-Core.ps1') -Label 'wad/Pesto-Core.ps1'
Assert-IconPathSoft -Path (Join-Path $wad 'Pesto.Engine.Runtime.ps1') -Label 'module Engine genere'
Write-Output "CompiledHelpers63 : $n/$n PASS"

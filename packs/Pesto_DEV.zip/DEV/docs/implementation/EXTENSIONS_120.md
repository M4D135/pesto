# Extensions livrées — 18 octobre 2026

Les points 109, 111, 114 et 117 ont des parcours exécutables dans le moteur. Leur
validation porte sur des tests locaux de contrats et de comportement, avec doubles
AD/Windows. Aucun test VM ni qualification de domaine réel n'a été effectué.
Le produit cible toujours Windows PowerShell 5.1 x64 et .NET Framework 4.7.2.

## 111 — Scénarios administrés

`POLICY.Scenario` accepte un objet fermé. Exemple :

```json
{"Schema":1,"Name":"Portables Paris","Required":["Type","ServiceCode"],
 "Allowed":{"Type":["P"],"SiteCode":["PA"]},"Locked":{"ServiceCode":"INF"}}
```

Champs : `Type`, `SiteCode`, `ServiceCode`, `TargetOU`. Les valeurs autorisées sont
des listes, les valeurs verrouillées des chaînes uniques. Une valeur verrouillée
contradictoire avec une liste autorisée est refusée. Les facettes sont extraites du
nom réellement demandé ; le moteur ne fait pas confiance aux seules étiquettes du
formulaire. Le bouton **Scénario administré…** affiche ces contraintes ; la préparation
refuse de produire un nom hors scénario. Les réglages locaux préservent le scénario.

Pour imposer ce scénario depuis la politique ordinateur, enregistrer le même JSON
comme valeur REG_SZ `ScenarioJson` sous `HKLM\SOFTWARE\Policies\M4D\Pesto`.
Cette valeur remplace le scénario local. Le moteur relit la politique avant la
mutation. Les droits AD et les autres exclusions restent obligatoires.

## 117 — Approbation distincte des campagnes

La valeur REG_SZ `CampaignApprovalJson`, dans la même clé HKLM, définit les campagnes
concernées et les signataires autorisés :

```json
{"Schema":1,"Campaigns":["PARIS-2026"],"Signers":[
 {"CertificateSHA256":"empreinte-sha256-du-certificat-DER-en-64-hex-minuscules",
  "Sid":"S-1-5-21-111-222-333-1001"}]}
```

`"*"` impose une campagne et un accord pour toute opération concernée par ce moteur.
La confiance vient exclusivement de HKLM, jamais du plan ou du certificat joint à
l'accord. Une modification locale de `cfg.json` ne supprime pas cette obligation.
Une suppression du certificat de cette liste révoque son autorisation.

Depuis une session Windows de l'approbateur, importer `Pesto.Engine.psd1`, lire les
plans préparés, puis appeler :

```powershell
$accord = New-PestoCampaignApproval -Plans $plans -Certificate $certificat -Minutes 60
```

La clé privée reste chez l'approbateur. RSA SHA-256, au moins 2048 bits, signe le
payload exact ; le certificat et la signature sont publics. L'accord lie campagne,
SID, échéance (24 heures maximum), domaine, machine opératrice, configuration,
identités source/destination et effets demandés (y compris le diff d'attributs ou
l'empreinte du blob ODJ). Les horodatages de préparation et les facettes redondantes
ne remplacent pas cette identité des effets. L'exécution du plan garde sa propre
validation d'intégrité et d'expiration.

Transmettre l'objet accord avec `-Approval` à `Invoke-PestoCommand`,
`Invoke-PestoUnattendedOperation`, `Invoke-PestoUnattendedJoin` ou au parcours
extensions. Le SID exécutant doit différer du SID signataire associé au certificat.
La signature, la politique actuelle et l'expiration sont revérifiées au passage
vers les effets. Ce mécanisme ne crée ni service de tickets ni serveur d'approbation.

## 114 — Attributs AD explicites

L'entrée `Invoke-PestoExtensionCommand` est exportée par `Pesto.Engine.psd1` ;
`wad/Invoke-PestoExtension.ps1` fournit le lanceur en processus séparé.

```powershell
# Dans une session Windows PowerShell 5.1 élevée, avec le module du pack importé :
$r = Invoke-PestoExtensionCommand -RuntimeRoot $wad -Action Attributes `
    -ObjectGuid $guid -Attributes ([pscustomobject]@{description='Atelier';location='Paris'}) `
    -OutPlanPath C:\Plans\attributs.json

$r = Invoke-PestoExtensionCommand -RuntimeRoot $wad -Action Attributes `
    -PlanPath C:\Plans\attributs.json -IdempotencyKey 'PARIS-2026/attributs-01' `
    -Approval $accord -Execute
```

Attributs autorisés : `description`, `location`, `managedBy`. Une chaîne vide efface
l'attribut. Une référence `managedBy` non vide est liée à un GUID du même domaine.
Le plan exporte un diff avant/après. À l'exécution, le moteur relit GUID, nom,
emplacement, valeurs initiales et référence `managedBy`. Il vérifie scénario,
exclusions, rôle de la cible, approbation et reçus antérieurs. Un changement concurrent
refuse la commande. Les ACL AD décident en dernier ressort des droits d'écriture.

Un seul `Set-ADObject` applique remplacement et effacement. L'intention `Attributes`
et le diff sont enregistrés avant cet appel. La relecture par GUID doit confirmer
chaque valeur. Une interruption reste incertaine, sans reprise automatique.
`-Action AttributeObserve -OperationId $id` relit les effets et peut réconcilier le
reçu ; elle n'envoie aucune écriture AD. Un nouveau plan ne contourne pas un reçu
incertain sur la même cible.

## 109 — Jonction hors connexion distincte

Activer explicitement `POLICY.AllowOfflineJoin`. La machine cible doit être un poste
Windows installé, élevé, hors domaine, sans renommage en attente. WinPE, les images
Windows hors ligne, la coordination réseau et les exclusions de groupes nécessitant
AD ne sont pas pris en charge par ce parcours. Aucune jonction en ligne de secours
n'est lancée.

L'administrateur de provisionnement fournit un fichier djoin pour **le nom actuel
exact de cette machine**, ainsi que le GUID du compte et son OU. Pesto consomme ce
blob opaque ; les métadonnées déclarées ne sont confirmées dans AD qu'à l'observation
après redémarrage. Il ne crée pas le compte de provisionnement dans cette étape.

```powershell
$r = Invoke-PestoExtensionCommand -RuntimeRoot $wad -Action OfflineImport `
    -BlobPath C:\Provisionnement\poste.odj -ObjectGuid $guid -TargetOU $ou -Execute
# Faire approuver $r.Plan si la politique de campagne l'exige.
Invoke-PestoExtensionCommand -RuntimeRoot $wad -Action OfflineApply `
    -BlobId $r.BlobId -Approval $accord -Execute
# Après le redémarrage volontaire et le retour réseau :
Invoke-PestoExtensionCommand -RuntimeRoot $wad -Action OfflineObserve -BlobId $r.BlobId
```

Le secret est chiffré par DPAPI LocalMachine dans ProgramData, avec une ACL limitée
à SYSTEM et aux administrateurs. Il ne figure ni dans le plan ni dans l'audit.
L'import ne supprime pas le fichier source : l'opérateur doit en gérer la protection
et la suppression selon sa procédure. Aucun transport ou stockage cloud n'est créé.
L'application expire après 24 heures ; cela **n'invalide pas le secret du compte AD**.

L'intention durable précède `djoin /requestodj /localos`. Un fichier plaintext
éphémère est nécessaire à djoin, dans le même dossier protégé ; il est supprimé en
fin de tentative avec la copie chiffrée. Après une coupure brutale, un résidu protégé
peut subsister et doit être retiré par l'administrateur après examen du reçu.
L'identifiant du blob empêche un nouvel import ou une nouvelle application silencieuse.
Le code 3010 signifie seulement qu'un redémarrage est requis. L'observation vérifie
le nouveau démarrage, la machine, le nom, le domaine, le GUID, l'OU et le canal sécurisé
avant de clôturer le reçu. Aucun redémarrage ni `-Repair` automatique.

Références Microsoft : [djoin](https://learn.microsoft.com/en-us/previous-versions/windows/it-pro/windows-server-2012-r2-and-2012/ff793312%28v%3Dws.11%29),
[contrat et sensibilité du blob ODJ](https://learn.microsoft.com/en-us/windows/win32/api/lmjoin/nf-lmjoin-netrequestofflinedomainjoin).

## Tests locaux

- `Run-ManagedExtensionsTests.ps1` : scénarios et vraies signatures RSA, y compris
  auto-approbation, altération, changement d'identité et révocation.
- `Run-ExtensionEffectsTests.ps1` : diff, refus sur état modifié, intention durable,
  écriture unique, reprise par observation, interruptions ODJ et absence de rejeu.
  Le cycle de vie et le schema des recus sont ceux du produit.
  Les transports AD, DPAPI, djoin et ACL sont des doubles ; ce n'est pas une recette Windows.
- Le manifeste et le lanceur natif couvrent les deux nouveaux scripts et le moteur généré.
